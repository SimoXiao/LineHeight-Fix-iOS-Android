var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/classCallCheck.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/classCallCheck.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/createClass.js":
/*!************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/createClass.js ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _typeof(obj) {
  "@babel/helpers - typeof";

  if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") {
    module.exports = _typeof = function _typeof(obj) {
      return typeof obj;
    };

    module.exports["default"] = module.exports, module.exports.__esModule = true;
  } else {
    module.exports = _typeof = function _typeof(obj) {
      return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    };

    module.exports["default"] = module.exports, module.exports.__esModule = true;
  }

  return _typeof(obj);
}

module.exports = _typeof;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./node_modules/from-sketch-json/lib/index.js":
/*!****************************************************!*\
  !*** ./node_modules/from-sketch-json/lib/index.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.fromSJSON = void 0;
/**
 * Versions based on discussion info: http://sketchplugins.com/d/316-sketch-version
 */
// Internal Sketch Version (ex: 95 => v47 and below)
var SKETCH_HIGHEST_COMPATIBLE_VERSION = '95';
/**
 * transform Sketch JSON to Sketch Native Object
 *
 * if there is any error then throw it
 * @param  json JSON 对象
 * @param {String} version
 */
exports.fromSJSON = function (json, version) {
    if (version === void 0) { version = SKETCH_HIGHEST_COMPATIBLE_VERSION; }
    var err = MOPointer.alloc().init();
    var unarchivedObjectFromDictionary = 
    // above v64
    MSJSONDictionaryUnarchiver.unarchivedObjectFromDictionary_asVersion_corruptionDetected_error ||
        // below v64
        MSJSONDictionaryUnarchiver.unarchiveObjectFromDictionary_asVersion_corruptionDetected_error;
    var decoded = unarchivedObjectFromDictionary(json, version, null, err);
    if (err.value() !== null) {
        console.error(err.value());
        throw new Error(err.value());
    }
    var mutableClass = decoded.class().mutableClass();
    return mutableClass.alloc().initWithImmutableModelObject(decoded);
};
exports.default = exports.fromSJSON;
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/lodash/_Hash.js":
/*!**************************************!*\
  !*** ./node_modules/lodash/_Hash.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var hashClear = __webpack_require__(/*! ./_hashClear */ "./node_modules/lodash/_hashClear.js"),
    hashDelete = __webpack_require__(/*! ./_hashDelete */ "./node_modules/lodash/_hashDelete.js"),
    hashGet = __webpack_require__(/*! ./_hashGet */ "./node_modules/lodash/_hashGet.js"),
    hashHas = __webpack_require__(/*! ./_hashHas */ "./node_modules/lodash/_hashHas.js"),
    hashSet = __webpack_require__(/*! ./_hashSet */ "./node_modules/lodash/_hashSet.js");

/**
 * Creates a hash object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function Hash(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `Hash`.
Hash.prototype.clear = hashClear;
Hash.prototype['delete'] = hashDelete;
Hash.prototype.get = hashGet;
Hash.prototype.has = hashHas;
Hash.prototype.set = hashSet;

module.exports = Hash;


/***/ }),

/***/ "./node_modules/lodash/_ListCache.js":
/*!*******************************************!*\
  !*** ./node_modules/lodash/_ListCache.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var listCacheClear = __webpack_require__(/*! ./_listCacheClear */ "./node_modules/lodash/_listCacheClear.js"),
    listCacheDelete = __webpack_require__(/*! ./_listCacheDelete */ "./node_modules/lodash/_listCacheDelete.js"),
    listCacheGet = __webpack_require__(/*! ./_listCacheGet */ "./node_modules/lodash/_listCacheGet.js"),
    listCacheHas = __webpack_require__(/*! ./_listCacheHas */ "./node_modules/lodash/_listCacheHas.js"),
    listCacheSet = __webpack_require__(/*! ./_listCacheSet */ "./node_modules/lodash/_listCacheSet.js");

/**
 * Creates an list cache object.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function ListCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `ListCache`.
ListCache.prototype.clear = listCacheClear;
ListCache.prototype['delete'] = listCacheDelete;
ListCache.prototype.get = listCacheGet;
ListCache.prototype.has = listCacheHas;
ListCache.prototype.set = listCacheSet;

module.exports = ListCache;


/***/ }),

/***/ "./node_modules/lodash/_Map.js":
/*!*************************************!*\
  !*** ./node_modules/lodash/_Map.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(/*! ./_getNative */ "./node_modules/lodash/_getNative.js"),
    root = __webpack_require__(/*! ./_root */ "./node_modules/lodash/_root.js");

/* Built-in method references that are verified to be native. */
var Map = getNative(root, 'Map');

module.exports = Map;


/***/ }),

/***/ "./node_modules/lodash/_MapCache.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_MapCache.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var mapCacheClear = __webpack_require__(/*! ./_mapCacheClear */ "./node_modules/lodash/_mapCacheClear.js"),
    mapCacheDelete = __webpack_require__(/*! ./_mapCacheDelete */ "./node_modules/lodash/_mapCacheDelete.js"),
    mapCacheGet = __webpack_require__(/*! ./_mapCacheGet */ "./node_modules/lodash/_mapCacheGet.js"),
    mapCacheHas = __webpack_require__(/*! ./_mapCacheHas */ "./node_modules/lodash/_mapCacheHas.js"),
    mapCacheSet = __webpack_require__(/*! ./_mapCacheSet */ "./node_modules/lodash/_mapCacheSet.js");

/**
 * Creates a map cache object to store key-value pairs.
 *
 * @private
 * @constructor
 * @param {Array} [entries] The key-value pairs to cache.
 */
function MapCache(entries) {
  var index = -1,
      length = entries == null ? 0 : entries.length;

  this.clear();
  while (++index < length) {
    var entry = entries[index];
    this.set(entry[0], entry[1]);
  }
}

// Add methods to `MapCache`.
MapCache.prototype.clear = mapCacheClear;
MapCache.prototype['delete'] = mapCacheDelete;
MapCache.prototype.get = mapCacheGet;
MapCache.prototype.has = mapCacheHas;
MapCache.prototype.set = mapCacheSet;

module.exports = MapCache;


/***/ }),

/***/ "./node_modules/lodash/_Symbol.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/_Symbol.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(/*! ./_root */ "./node_modules/lodash/_root.js");

/** Built-in value references. */
var Symbol = root.Symbol;

module.exports = Symbol;


/***/ }),

/***/ "./node_modules/lodash/_arrayMap.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_arrayMap.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * A specialized version of `_.map` for arrays without support for iteratee
 * shorthands.
 *
 * @private
 * @param {Array} [array] The array to iterate over.
 * @param {Function} iteratee The function invoked per iteration.
 * @returns {Array} Returns the new mapped array.
 */
function arrayMap(array, iteratee) {
  var index = -1,
      length = array == null ? 0 : array.length,
      result = Array(length);

  while (++index < length) {
    result[index] = iteratee(array[index], index, array);
  }
  return result;
}

module.exports = arrayMap;


/***/ }),

/***/ "./node_modules/lodash/_assocIndexOf.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_assocIndexOf.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var eq = __webpack_require__(/*! ./eq */ "./node_modules/lodash/eq.js");

/**
 * Gets the index at which the `key` is found in `array` of key-value pairs.
 *
 * @private
 * @param {Array} array The array to inspect.
 * @param {*} key The key to search for.
 * @returns {number} Returns the index of the matched value, else `-1`.
 */
function assocIndexOf(array, key) {
  var length = array.length;
  while (length--) {
    if (eq(array[length][0], key)) {
      return length;
    }
  }
  return -1;
}

module.exports = assocIndexOf;


/***/ }),

/***/ "./node_modules/lodash/_baseGet.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/_baseGet.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var castPath = __webpack_require__(/*! ./_castPath */ "./node_modules/lodash/_castPath.js"),
    toKey = __webpack_require__(/*! ./_toKey */ "./node_modules/lodash/_toKey.js");

/**
 * The base implementation of `_.get` without support for default values.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @returns {*} Returns the resolved value.
 */
function baseGet(object, path) {
  path = castPath(path, object);

  var index = 0,
      length = path.length;

  while (object != null && index < length) {
    object = object[toKey(path[index++])];
  }
  return (index && index == length) ? object : undefined;
}

module.exports = baseGet;


/***/ }),

/***/ "./node_modules/lodash/_baseGetTag.js":
/*!********************************************!*\
  !*** ./node_modules/lodash/_baseGetTag.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(/*! ./_Symbol */ "./node_modules/lodash/_Symbol.js"),
    getRawTag = __webpack_require__(/*! ./_getRawTag */ "./node_modules/lodash/_getRawTag.js"),
    objectToString = __webpack_require__(/*! ./_objectToString */ "./node_modules/lodash/_objectToString.js");

/** `Object#toString` result references. */
var nullTag = '[object Null]',
    undefinedTag = '[object Undefined]';

/** Built-in value references. */
var symToStringTag = Symbol ? Symbol.toStringTag : undefined;

/**
 * The base implementation of `getTag` without fallbacks for buggy environments.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the `toStringTag`.
 */
function baseGetTag(value) {
  if (value == null) {
    return value === undefined ? undefinedTag : nullTag;
  }
  return (symToStringTag && symToStringTag in Object(value))
    ? getRawTag(value)
    : objectToString(value);
}

module.exports = baseGetTag;


/***/ }),

/***/ "./node_modules/lodash/_baseIsNative.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_baseIsNative.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isFunction = __webpack_require__(/*! ./isFunction */ "./node_modules/lodash/isFunction.js"),
    isMasked = __webpack_require__(/*! ./_isMasked */ "./node_modules/lodash/_isMasked.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js"),
    toSource = __webpack_require__(/*! ./_toSource */ "./node_modules/lodash/_toSource.js");

/**
 * Used to match `RegExp`
 * [syntax characters](http://ecma-international.org/ecma-262/7.0/#sec-patterns).
 */
var reRegExpChar = /[\\^$.*+?()[\]{}|]/g;

/** Used to detect host constructors (Safari). */
var reIsHostCtor = /^\[object .+?Constructor\]$/;

/** Used for built-in method references. */
var funcProto = Function.prototype,
    objectProto = Object.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/** Used to detect if a method is native. */
var reIsNative = RegExp('^' +
  funcToString.call(hasOwnProperty).replace(reRegExpChar, '\\$&')
  .replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, '$1.*?') + '$'
);

/**
 * The base implementation of `_.isNative` without bad shim checks.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a native function,
 *  else `false`.
 */
function baseIsNative(value) {
  if (!isObject(value) || isMasked(value)) {
    return false;
  }
  var pattern = isFunction(value) ? reIsNative : reIsHostCtor;
  return pattern.test(toSource(value));
}

module.exports = baseIsNative;


/***/ }),

/***/ "./node_modules/lodash/_baseToString.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_baseToString.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(/*! ./_Symbol */ "./node_modules/lodash/_Symbol.js"),
    arrayMap = __webpack_require__(/*! ./_arrayMap */ "./node_modules/lodash/_arrayMap.js"),
    isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isSymbol = __webpack_require__(/*! ./isSymbol */ "./node_modules/lodash/isSymbol.js");

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/** Used to convert symbols to primitives and strings. */
var symbolProto = Symbol ? Symbol.prototype : undefined,
    symbolToString = symbolProto ? symbolProto.toString : undefined;

/**
 * The base implementation of `_.toString` which doesn't convert nullish
 * values to empty strings.
 *
 * @private
 * @param {*} value The value to process.
 * @returns {string} Returns the string.
 */
function baseToString(value) {
  // Exit early for strings to avoid a performance hit in some environments.
  if (typeof value == 'string') {
    return value;
  }
  if (isArray(value)) {
    // Recursively convert values (susceptible to call stack limits).
    return arrayMap(value, baseToString) + '';
  }
  if (isSymbol(value)) {
    return symbolToString ? symbolToString.call(value) : '';
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

module.exports = baseToString;


/***/ }),

/***/ "./node_modules/lodash/_castPath.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_castPath.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isKey = __webpack_require__(/*! ./_isKey */ "./node_modules/lodash/_isKey.js"),
    stringToPath = __webpack_require__(/*! ./_stringToPath */ "./node_modules/lodash/_stringToPath.js"),
    toString = __webpack_require__(/*! ./toString */ "./node_modules/lodash/toString.js");

/**
 * Casts `value` to a path array if it's not one.
 *
 * @private
 * @param {*} value The value to inspect.
 * @param {Object} [object] The object to query keys on.
 * @returns {Array} Returns the cast property path array.
 */
function castPath(value, object) {
  if (isArray(value)) {
    return value;
  }
  return isKey(value, object) ? [value] : stringToPath(toString(value));
}

module.exports = castPath;


/***/ }),

/***/ "./node_modules/lodash/_coreJsData.js":
/*!********************************************!*\
  !*** ./node_modules/lodash/_coreJsData.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var root = __webpack_require__(/*! ./_root */ "./node_modules/lodash/_root.js");

/** Used to detect overreaching core-js shims. */
var coreJsData = root['__core-js_shared__'];

module.exports = coreJsData;


/***/ }),

/***/ "./node_modules/lodash/_freeGlobal.js":
/*!********************************************!*\
  !*** ./node_modules/lodash/_freeGlobal.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

module.exports = freeGlobal;


/***/ }),

/***/ "./node_modules/lodash/_getMapData.js":
/*!********************************************!*\
  !*** ./node_modules/lodash/_getMapData.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isKeyable = __webpack_require__(/*! ./_isKeyable */ "./node_modules/lodash/_isKeyable.js");

/**
 * Gets the data for `map`.
 *
 * @private
 * @param {Object} map The map to query.
 * @param {string} key The reference key.
 * @returns {*} Returns the map data.
 */
function getMapData(map, key) {
  var data = map.__data__;
  return isKeyable(key)
    ? data[typeof key == 'string' ? 'string' : 'hash']
    : data.map;
}

module.exports = getMapData;


/***/ }),

/***/ "./node_modules/lodash/_getNative.js":
/*!*******************************************!*\
  !*** ./node_modules/lodash/_getNative.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseIsNative = __webpack_require__(/*! ./_baseIsNative */ "./node_modules/lodash/_baseIsNative.js"),
    getValue = __webpack_require__(/*! ./_getValue */ "./node_modules/lodash/_getValue.js");

/**
 * Gets the native function at `key` of `object`.
 *
 * @private
 * @param {Object} object The object to query.
 * @param {string} key The key of the method to get.
 * @returns {*} Returns the function if it's native, else `undefined`.
 */
function getNative(object, key) {
  var value = getValue(object, key);
  return baseIsNative(value) ? value : undefined;
}

module.exports = getNative;


/***/ }),

/***/ "./node_modules/lodash/_getRawTag.js":
/*!*******************************************!*\
  !*** ./node_modules/lodash/_getRawTag.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Symbol = __webpack_require__(/*! ./_Symbol */ "./node_modules/lodash/_Symbol.js");

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString = objectProto.toString;

/** Built-in value references. */
var symToStringTag = Symbol ? Symbol.toStringTag : undefined;

/**
 * A specialized version of `baseGetTag` which ignores `Symbol.toStringTag` values.
 *
 * @private
 * @param {*} value The value to query.
 * @returns {string} Returns the raw `toStringTag`.
 */
function getRawTag(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag),
      tag = value[symToStringTag];

  try {
    value[symToStringTag] = undefined;
    var unmasked = true;
  } catch (e) {}

  var result = nativeObjectToString.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag] = tag;
    } else {
      delete value[symToStringTag];
    }
  }
  return result;
}

module.exports = getRawTag;


/***/ }),

/***/ "./node_modules/lodash/_getValue.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_getValue.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Gets the value at `key` of `object`.
 *
 * @private
 * @param {Object} [object] The object to query.
 * @param {string} key The key of the property to get.
 * @returns {*} Returns the property value.
 */
function getValue(object, key) {
  return object == null ? undefined : object[key];
}

module.exports = getValue;


/***/ }),

/***/ "./node_modules/lodash/_hashClear.js":
/*!*******************************************!*\
  !*** ./node_modules/lodash/_hashClear.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(/*! ./_nativeCreate */ "./node_modules/lodash/_nativeCreate.js");

/**
 * Removes all key-value entries from the hash.
 *
 * @private
 * @name clear
 * @memberOf Hash
 */
function hashClear() {
  this.__data__ = nativeCreate ? nativeCreate(null) : {};
  this.size = 0;
}

module.exports = hashClear;


/***/ }),

/***/ "./node_modules/lodash/_hashDelete.js":
/*!********************************************!*\
  !*** ./node_modules/lodash/_hashDelete.js ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Removes `key` and its value from the hash.
 *
 * @private
 * @name delete
 * @memberOf Hash
 * @param {Object} hash The hash to modify.
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function hashDelete(key) {
  var result = this.has(key) && delete this.__data__[key];
  this.size -= result ? 1 : 0;
  return result;
}

module.exports = hashDelete;


/***/ }),

/***/ "./node_modules/lodash/_hashGet.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/_hashGet.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(/*! ./_nativeCreate */ "./node_modules/lodash/_nativeCreate.js");

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Gets the hash value for `key`.
 *
 * @private
 * @name get
 * @memberOf Hash
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function hashGet(key) {
  var data = this.__data__;
  if (nativeCreate) {
    var result = data[key];
    return result === HASH_UNDEFINED ? undefined : result;
  }
  return hasOwnProperty.call(data, key) ? data[key] : undefined;
}

module.exports = hashGet;


/***/ }),

/***/ "./node_modules/lodash/_hashHas.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/_hashHas.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(/*! ./_nativeCreate */ "./node_modules/lodash/_nativeCreate.js");

/** Used for built-in method references. */
var objectProto = Object.prototype;

/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;

/**
 * Checks if a hash value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf Hash
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function hashHas(key) {
  var data = this.__data__;
  return nativeCreate ? (data[key] !== undefined) : hasOwnProperty.call(data, key);
}

module.exports = hashHas;


/***/ }),

/***/ "./node_modules/lodash/_hashSet.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/_hashSet.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var nativeCreate = __webpack_require__(/*! ./_nativeCreate */ "./node_modules/lodash/_nativeCreate.js");

/** Used to stand-in for `undefined` hash values. */
var HASH_UNDEFINED = '__lodash_hash_undefined__';

/**
 * Sets the hash `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf Hash
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the hash instance.
 */
function hashSet(key, value) {
  var data = this.__data__;
  this.size += this.has(key) ? 0 : 1;
  data[key] = (nativeCreate && value === undefined) ? HASH_UNDEFINED : value;
  return this;
}

module.exports = hashSet;


/***/ }),

/***/ "./node_modules/lodash/_isKey.js":
/*!***************************************!*\
  !*** ./node_modules/lodash/_isKey.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isArray = __webpack_require__(/*! ./isArray */ "./node_modules/lodash/isArray.js"),
    isSymbol = __webpack_require__(/*! ./isSymbol */ "./node_modules/lodash/isSymbol.js");

/** Used to match property names within property paths. */
var reIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    reIsPlainProp = /^\w*$/;

/**
 * Checks if `value` is a property name and not a property path.
 *
 * @private
 * @param {*} value The value to check.
 * @param {Object} [object] The object to query keys on.
 * @returns {boolean} Returns `true` if `value` is a property name, else `false`.
 */
function isKey(value, object) {
  if (isArray(value)) {
    return false;
  }
  var type = typeof value;
  if (type == 'number' || type == 'symbol' || type == 'boolean' ||
      value == null || isSymbol(value)) {
    return true;
  }
  return reIsPlainProp.test(value) || !reIsDeepProp.test(value) ||
    (object != null && value in Object(object));
}

module.exports = isKey;


/***/ }),

/***/ "./node_modules/lodash/_isKeyable.js":
/*!*******************************************!*\
  !*** ./node_modules/lodash/_isKeyable.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Checks if `value` is suitable for use as unique object key.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is suitable, else `false`.
 */
function isKeyable(value) {
  var type = typeof value;
  return (type == 'string' || type == 'number' || type == 'symbol' || type == 'boolean')
    ? (value !== '__proto__')
    : (value === null);
}

module.exports = isKeyable;


/***/ }),

/***/ "./node_modules/lodash/_isMasked.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_isMasked.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var coreJsData = __webpack_require__(/*! ./_coreJsData */ "./node_modules/lodash/_coreJsData.js");

/** Used to detect methods masquerading as native. */
var maskSrcKey = (function() {
  var uid = /[^.]+$/.exec(coreJsData && coreJsData.keys && coreJsData.keys.IE_PROTO || '');
  return uid ? ('Symbol(src)_1.' + uid) : '';
}());

/**
 * Checks if `func` has its source masked.
 *
 * @private
 * @param {Function} func The function to check.
 * @returns {boolean} Returns `true` if `func` is masked, else `false`.
 */
function isMasked(func) {
  return !!maskSrcKey && (maskSrcKey in func);
}

module.exports = isMasked;


/***/ }),

/***/ "./node_modules/lodash/_listCacheClear.js":
/*!************************************************!*\
  !*** ./node_modules/lodash/_listCacheClear.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Removes all key-value entries from the list cache.
 *
 * @private
 * @name clear
 * @memberOf ListCache
 */
function listCacheClear() {
  this.__data__ = [];
  this.size = 0;
}

module.exports = listCacheClear;


/***/ }),

/***/ "./node_modules/lodash/_listCacheDelete.js":
/*!*************************************************!*\
  !*** ./node_modules/lodash/_listCacheDelete.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(/*! ./_assocIndexOf */ "./node_modules/lodash/_assocIndexOf.js");

/** Used for built-in method references. */
var arrayProto = Array.prototype;

/** Built-in value references. */
var splice = arrayProto.splice;

/**
 * Removes `key` and its value from the list cache.
 *
 * @private
 * @name delete
 * @memberOf ListCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function listCacheDelete(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    return false;
  }
  var lastIndex = data.length - 1;
  if (index == lastIndex) {
    data.pop();
  } else {
    splice.call(data, index, 1);
  }
  --this.size;
  return true;
}

module.exports = listCacheDelete;


/***/ }),

/***/ "./node_modules/lodash/_listCacheGet.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_listCacheGet.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(/*! ./_assocIndexOf */ "./node_modules/lodash/_assocIndexOf.js");

/**
 * Gets the list cache value for `key`.
 *
 * @private
 * @name get
 * @memberOf ListCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function listCacheGet(key) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  return index < 0 ? undefined : data[index][1];
}

module.exports = listCacheGet;


/***/ }),

/***/ "./node_modules/lodash/_listCacheHas.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_listCacheHas.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(/*! ./_assocIndexOf */ "./node_modules/lodash/_assocIndexOf.js");

/**
 * Checks if a list cache value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf ListCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function listCacheHas(key) {
  return assocIndexOf(this.__data__, key) > -1;
}

module.exports = listCacheHas;


/***/ }),

/***/ "./node_modules/lodash/_listCacheSet.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_listCacheSet.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var assocIndexOf = __webpack_require__(/*! ./_assocIndexOf */ "./node_modules/lodash/_assocIndexOf.js");

/**
 * Sets the list cache `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf ListCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the list cache instance.
 */
function listCacheSet(key, value) {
  var data = this.__data__,
      index = assocIndexOf(data, key);

  if (index < 0) {
    ++this.size;
    data.push([key, value]);
  } else {
    data[index][1] = value;
  }
  return this;
}

module.exports = listCacheSet;


/***/ }),

/***/ "./node_modules/lodash/_mapCacheClear.js":
/*!***********************************************!*\
  !*** ./node_modules/lodash/_mapCacheClear.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var Hash = __webpack_require__(/*! ./_Hash */ "./node_modules/lodash/_Hash.js"),
    ListCache = __webpack_require__(/*! ./_ListCache */ "./node_modules/lodash/_ListCache.js"),
    Map = __webpack_require__(/*! ./_Map */ "./node_modules/lodash/_Map.js");

/**
 * Removes all key-value entries from the map.
 *
 * @private
 * @name clear
 * @memberOf MapCache
 */
function mapCacheClear() {
  this.size = 0;
  this.__data__ = {
    'hash': new Hash,
    'map': new (Map || ListCache),
    'string': new Hash
  };
}

module.exports = mapCacheClear;


/***/ }),

/***/ "./node_modules/lodash/_mapCacheDelete.js":
/*!************************************************!*\
  !*** ./node_modules/lodash/_mapCacheDelete.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(/*! ./_getMapData */ "./node_modules/lodash/_getMapData.js");

/**
 * Removes `key` and its value from the map.
 *
 * @private
 * @name delete
 * @memberOf MapCache
 * @param {string} key The key of the value to remove.
 * @returns {boolean} Returns `true` if the entry was removed, else `false`.
 */
function mapCacheDelete(key) {
  var result = getMapData(this, key)['delete'](key);
  this.size -= result ? 1 : 0;
  return result;
}

module.exports = mapCacheDelete;


/***/ }),

/***/ "./node_modules/lodash/_mapCacheGet.js":
/*!*********************************************!*\
  !*** ./node_modules/lodash/_mapCacheGet.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(/*! ./_getMapData */ "./node_modules/lodash/_getMapData.js");

/**
 * Gets the map value for `key`.
 *
 * @private
 * @name get
 * @memberOf MapCache
 * @param {string} key The key of the value to get.
 * @returns {*} Returns the entry value.
 */
function mapCacheGet(key) {
  return getMapData(this, key).get(key);
}

module.exports = mapCacheGet;


/***/ }),

/***/ "./node_modules/lodash/_mapCacheHas.js":
/*!*********************************************!*\
  !*** ./node_modules/lodash/_mapCacheHas.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(/*! ./_getMapData */ "./node_modules/lodash/_getMapData.js");

/**
 * Checks if a map value for `key` exists.
 *
 * @private
 * @name has
 * @memberOf MapCache
 * @param {string} key The key of the entry to check.
 * @returns {boolean} Returns `true` if an entry for `key` exists, else `false`.
 */
function mapCacheHas(key) {
  return getMapData(this, key).has(key);
}

module.exports = mapCacheHas;


/***/ }),

/***/ "./node_modules/lodash/_mapCacheSet.js":
/*!*********************************************!*\
  !*** ./node_modules/lodash/_mapCacheSet.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getMapData = __webpack_require__(/*! ./_getMapData */ "./node_modules/lodash/_getMapData.js");

/**
 * Sets the map `key` to `value`.
 *
 * @private
 * @name set
 * @memberOf MapCache
 * @param {string} key The key of the value to set.
 * @param {*} value The value to set.
 * @returns {Object} Returns the map cache instance.
 */
function mapCacheSet(key, value) {
  var data = getMapData(this, key),
      size = data.size;

  data.set(key, value);
  this.size += data.size == size ? 0 : 1;
  return this;
}

module.exports = mapCacheSet;


/***/ }),

/***/ "./node_modules/lodash/_memoizeCapped.js":
/*!***********************************************!*\
  !*** ./node_modules/lodash/_memoizeCapped.js ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var memoize = __webpack_require__(/*! ./memoize */ "./node_modules/lodash/memoize.js");

/** Used as the maximum memoize cache size. */
var MAX_MEMOIZE_SIZE = 500;

/**
 * A specialized version of `_.memoize` which clears the memoized function's
 * cache when it exceeds `MAX_MEMOIZE_SIZE`.
 *
 * @private
 * @param {Function} func The function to have its output memoized.
 * @returns {Function} Returns the new memoized function.
 */
function memoizeCapped(func) {
  var result = memoize(func, function(key) {
    if (cache.size === MAX_MEMOIZE_SIZE) {
      cache.clear();
    }
    return key;
  });

  var cache = result.cache;
  return result;
}

module.exports = memoizeCapped;


/***/ }),

/***/ "./node_modules/lodash/_nativeCreate.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_nativeCreate.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var getNative = __webpack_require__(/*! ./_getNative */ "./node_modules/lodash/_getNative.js");

/* Built-in method references that are verified to be native. */
var nativeCreate = getNative(Object, 'create');

module.exports = nativeCreate;


/***/ }),

/***/ "./node_modules/lodash/_objectToString.js":
/*!************************************************!*\
  !*** ./node_modules/lodash/_objectToString.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var nativeObjectToString = objectProto.toString;

/**
 * Converts `value` to a string using `Object.prototype.toString`.
 *
 * @private
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 */
function objectToString(value) {
  return nativeObjectToString.call(value);
}

module.exports = objectToString;


/***/ }),

/***/ "./node_modules/lodash/_root.js":
/*!**************************************!*\
  !*** ./node_modules/lodash/_root.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var freeGlobal = __webpack_require__(/*! ./_freeGlobal */ "./node_modules/lodash/_freeGlobal.js");

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

module.exports = root;


/***/ }),

/***/ "./node_modules/lodash/_stringToPath.js":
/*!**********************************************!*\
  !*** ./node_modules/lodash/_stringToPath.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var memoizeCapped = __webpack_require__(/*! ./_memoizeCapped */ "./node_modules/lodash/_memoizeCapped.js");

/** Used to match property names within property paths. */
var rePropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g;

/** Used to match backslashes in property paths. */
var reEscapeChar = /\\(\\)?/g;

/**
 * Converts `string` to a property path array.
 *
 * @private
 * @param {string} string The string to convert.
 * @returns {Array} Returns the property path array.
 */
var stringToPath = memoizeCapped(function(string) {
  var result = [];
  if (string.charCodeAt(0) === 46 /* . */) {
    result.push('');
  }
  string.replace(rePropName, function(match, number, quote, subString) {
    result.push(quote ? subString.replace(reEscapeChar, '$1') : (number || match));
  });
  return result;
});

module.exports = stringToPath;


/***/ }),

/***/ "./node_modules/lodash/_toKey.js":
/*!***************************************!*\
  !*** ./node_modules/lodash/_toKey.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var isSymbol = __webpack_require__(/*! ./isSymbol */ "./node_modules/lodash/isSymbol.js");

/** Used as references for various `Number` constants. */
var INFINITY = 1 / 0;

/**
 * Converts `value` to a string key if it's not a string or symbol.
 *
 * @private
 * @param {*} value The value to inspect.
 * @returns {string|symbol} Returns the key.
 */
function toKey(value) {
  if (typeof value == 'string' || isSymbol(value)) {
    return value;
  }
  var result = (value + '');
  return (result == '0' && (1 / value) == -INFINITY) ? '-0' : result;
}

module.exports = toKey;


/***/ }),

/***/ "./node_modules/lodash/_toSource.js":
/*!******************************************!*\
  !*** ./node_modules/lodash/_toSource.js ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/** Used for built-in method references. */
var funcProto = Function.prototype;

/** Used to resolve the decompiled source of functions. */
var funcToString = funcProto.toString;

/**
 * Converts `func` to its source code.
 *
 * @private
 * @param {Function} func The function to convert.
 * @returns {string} Returns the source code.
 */
function toSource(func) {
  if (func != null) {
    try {
      return funcToString.call(func);
    } catch (e) {}
    try {
      return (func + '');
    } catch (e) {}
  }
  return '';
}

module.exports = toSource;


/***/ }),

/***/ "./node_modules/lodash/eq.js":
/*!***********************************!*\
  !*** ./node_modules/lodash/eq.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Performs a
 * [`SameValueZero`](http://ecma-international.org/ecma-262/7.0/#sec-samevaluezero)
 * comparison between two values to determine if they are equivalent.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to compare.
 * @param {*} other The other value to compare.
 * @returns {boolean} Returns `true` if the values are equivalent, else `false`.
 * @example
 *
 * var object = { 'a': 1 };
 * var other = { 'a': 1 };
 *
 * _.eq(object, object);
 * // => true
 *
 * _.eq(object, other);
 * // => false
 *
 * _.eq('a', 'a');
 * // => true
 *
 * _.eq('a', Object('a'));
 * // => false
 *
 * _.eq(NaN, NaN);
 * // => true
 */
function eq(value, other) {
  return value === other || (value !== value && other !== other);
}

module.exports = eq;


/***/ }),

/***/ "./node_modules/lodash/get.js":
/*!************************************!*\
  !*** ./node_modules/lodash/get.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGet = __webpack_require__(/*! ./_baseGet */ "./node_modules/lodash/_baseGet.js");

/**
 * Gets the value at `path` of `object`. If the resolved value is
 * `undefined`, the `defaultValue` is returned in its place.
 *
 * @static
 * @memberOf _
 * @since 3.7.0
 * @category Object
 * @param {Object} object The object to query.
 * @param {Array|string} path The path of the property to get.
 * @param {*} [defaultValue] The value returned for `undefined` resolved values.
 * @returns {*} Returns the resolved value.
 * @example
 *
 * var object = { 'a': [{ 'b': { 'c': 3 } }] };
 *
 * _.get(object, 'a[0].b.c');
 * // => 3
 *
 * _.get(object, ['a', '0', 'b', 'c']);
 * // => 3
 *
 * _.get(object, 'a.b.c', 'default');
 * // => 'default'
 */
function get(object, path, defaultValue) {
  var result = object == null ? undefined : baseGet(object, path);
  return result === undefined ? defaultValue : result;
}

module.exports = get;


/***/ }),

/***/ "./node_modules/lodash/isArray.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/isArray.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;

module.exports = isArray;


/***/ }),

/***/ "./node_modules/lodash/isFunction.js":
/*!*******************************************!*\
  !*** ./node_modules/lodash/isFunction.js ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(/*! ./_baseGetTag */ "./node_modules/lodash/_baseGetTag.js"),
    isObject = __webpack_require__(/*! ./isObject */ "./node_modules/lodash/isObject.js");

/** `Object#toString` result references. */
var asyncTag = '[object AsyncFunction]',
    funcTag = '[object Function]',
    genTag = '[object GeneratorFunction]',
    proxyTag = '[object Proxy]';

/**
 * Checks if `value` is classified as a `Function` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a function, else `false`.
 * @example
 *
 * _.isFunction(_);
 * // => true
 *
 * _.isFunction(/abc/);
 * // => false
 */
function isFunction(value) {
  if (!isObject(value)) {
    return false;
  }
  // The use of `Object#toString` avoids issues with the `typeof` operator
  // in Safari 9 which returns 'object' for typed arrays and other constructors.
  var tag = baseGetTag(value);
  return tag == funcTag || tag == genTag || tag == asyncTag || tag == proxyTag;
}

module.exports = isFunction;


/***/ }),

/***/ "./node_modules/lodash/isObject.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/isObject.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return value != null && (type == 'object' || type == 'function');
}

module.exports = isObject;


/***/ }),

/***/ "./node_modules/lodash/isObjectLike.js":
/*!*********************************************!*\
  !*** ./node_modules/lodash/isObjectLike.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return value != null && typeof value == 'object';
}

module.exports = isObjectLike;


/***/ }),

/***/ "./node_modules/lodash/isSymbol.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/isSymbol.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseGetTag = __webpack_require__(/*! ./_baseGetTag */ "./node_modules/lodash/_baseGetTag.js"),
    isObjectLike = __webpack_require__(/*! ./isObjectLike */ "./node_modules/lodash/isObjectLike.js");

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && baseGetTag(value) == symbolTag);
}

module.exports = isSymbol;


/***/ }),

/***/ "./node_modules/lodash/memoize.js":
/*!****************************************!*\
  !*** ./node_modules/lodash/memoize.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var MapCache = __webpack_require__(/*! ./_MapCache */ "./node_modules/lodash/_MapCache.js");

/** Error message constants. */
var FUNC_ERROR_TEXT = 'Expected a function';

/**
 * Creates a function that memoizes the result of `func`. If `resolver` is
 * provided, it determines the cache key for storing the result based on the
 * arguments provided to the memoized function. By default, the first argument
 * provided to the memoized function is used as the map cache key. The `func`
 * is invoked with the `this` binding of the memoized function.
 *
 * **Note:** The cache is exposed as the `cache` property on the memoized
 * function. Its creation may be customized by replacing the `_.memoize.Cache`
 * constructor with one whose instances implement the
 * [`Map`](http://ecma-international.org/ecma-262/7.0/#sec-properties-of-the-map-prototype-object)
 * method interface of `clear`, `delete`, `get`, `has`, and `set`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to have its output memoized.
 * @param {Function} [resolver] The function to resolve the cache key.
 * @returns {Function} Returns the new memoized function.
 * @example
 *
 * var object = { 'a': 1, 'b': 2 };
 * var other = { 'c': 3, 'd': 4 };
 *
 * var values = _.memoize(_.values);
 * values(object);
 * // => [1, 2]
 *
 * values(other);
 * // => [3, 4]
 *
 * object.a = 2;
 * values(object);
 * // => [1, 2]
 *
 * // Modify the result cache.
 * values.cache.set(object, ['a', 'b']);
 * values(object);
 * // => ['a', 'b']
 *
 * // Replace `_.memoize.Cache`.
 * _.memoize.Cache = WeakMap;
 */
function memoize(func, resolver) {
  if (typeof func != 'function' || (resolver != null && typeof resolver != 'function')) {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  var memoized = function() {
    var args = arguments,
        key = resolver ? resolver.apply(this, args) : args[0],
        cache = memoized.cache;

    if (cache.has(key)) {
      return cache.get(key);
    }
    var result = func.apply(this, args);
    memoized.cache = cache.set(key, result) || cache;
    return result;
  };
  memoized.cache = new (memoize.Cache || MapCache);
  return memoized;
}

// Expose `MapCache`.
memoize.Cache = MapCache;

module.exports = memoize;


/***/ }),

/***/ "./node_modules/lodash/toString.js":
/*!*****************************************!*\
  !*** ./node_modules/lodash/toString.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var baseToString = __webpack_require__(/*! ./_baseToString */ "./node_modules/lodash/_baseToString.js");

/**
 * Converts `value` to a string. An empty string is returned for `null`
 * and `undefined` values. The sign of `-0` is preserved.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to convert.
 * @returns {string} Returns the converted string.
 * @example
 *
 * _.toString(null);
 * // => ''
 *
 * _.toString(-0);
 * // => '-0'
 *
 * _.toString([1, 2, 3]);
 * // => '1,2,3'
 */
function toString(value) {
  return value == null ? '' : baseToString(value);
}

module.exports = toString;


/***/ }),

/***/ "./node_modules/mocha-js-delegate/index.js":
/*!*************************************************!*\
  !*** ./node_modules/mocha-js-delegate/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* globals MOClassDescription, NSObject, NSSelectorFromString, NSClassFromString, MOPropertyDescription */

module.exports = function MochaDelegate(definition, superclass) {
  var uniqueClassName =
    'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString()

  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(
    uniqueClassName,
    superclass || NSObject
  )

  // Storage
  var handlers = {}
  var ivars = {}

  // Define an instance method
  function setHandlerForSelector(selectorString, func) {
    var handlerHasBeenSet = selectorString in handlers
    var selector = NSSelectorFromString(selectorString)

    handlers[selectorString] = func

    /*
      For some reason, Mocha acts weird about arguments: https://github.com/logancollins/Mocha/issues/28
      We have to basically create a dynamic handler with a likewise dynamic number of predefined arguments.
    */
    if (!handlerHasBeenSet) {
      var args = []
      var regex = /:/g
      while (regex.exec(selectorString)) {
        args.push('arg' + args.length)
      }

      // eslint-disable-next-line no-eval
      var dynamicFunction = eval(
        '(function (' +
          args.join(', ') +
          ') { return handlers[selectorString].apply(this, arguments); })'
      )

      delegateClassDesc.addInstanceMethodWithSelector_function(
        selector,
        dynamicFunction
      )
    }
  }

  // define a property
  function setIvar(key, value) {
    var ivarHasBeenSet = key in handlers

    ivars[key] = value

    if (!ivarHasBeenSet) {
      delegateClassDesc.addInstanceVariableWithName_typeEncoding(key, '@')
      var description = MOPropertyDescription.new()
      description.name = key
      description.typeEncoding = '@'
      description.weak = true
      description.ivarName = key
      delegateClassDesc.addProperty(description)
    }
  }

  this.getClass = function() {
    return NSClassFromString(uniqueClassName)
  }

  this.getClassInstance = function(instanceVariables) {
    var instance = NSClassFromString(uniqueClassName).new()
    Object.keys(ivars).forEach(function(key) {
      instance[key] = ivars[key]
    })
    Object.keys(instanceVariables || {}).forEach(function(key) {
      instance[key] = instanceVariables[key]
    })
    return instance
  }
  // alias
  this.new = this.getClassInstance

  // Convenience
  if (typeof definition === 'object') {
    Object.keys(definition).forEach(
      function(key) {
        if (typeof definition[key] === 'function') {
          setHandlerForSelector(key, definition[key])
        } else {
          setIvar(key, definition[key])
        }
      }
    )
  }

  delegateClassDesc.registerClass()
}


/***/ }),

/***/ "./node_modules/querystringify/index.js":
/*!**********************************************!*\
  !*** ./node_modules/querystringify/index.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var has = Object.prototype.hasOwnProperty
  , undef;

/**
 * Decode a URI encoded string.
 *
 * @param {String} input The URI encoded string.
 * @returns {String|Null} The decoded string.
 * @api private
 */
function decode(input) {
  try {
    return decodeURIComponent(input.replace(/\+/g, ' '));
  } catch (e) {
    return null;
  }
}

/**
 * Attempts to encode a given input.
 *
 * @param {String} input The string that needs to be encoded.
 * @returns {String|Null} The encoded string.
 * @api private
 */
function encode(input) {
  try {
    return encodeURIComponent(input);
  } catch (e) {
    return null;
  }
}

/**
 * Simple query string parser.
 *
 * @param {String} query The query string that needs to be parsed.
 * @returns {Object}
 * @api public
 */
function querystring(query) {
  var parser = /([^=?#&]+)=?([^&]*)/g
    , result = {}
    , part;

  while (part = parser.exec(query)) {
    var key = decode(part[1])
      , value = decode(part[2]);

    //
    // Prevent overriding of existing properties. This ensures that build-in
    // methods like `toString` or __proto__ are not overriden by malicious
    // querystrings.
    //
    // In the case if failed decoding, we want to omit the key/value pairs
    // from the result.
    //
    if (key === null || value === null || key in result) continue;
    result[key] = value;
  }

  return result;
}

/**
 * Transform a query string to an object.
 *
 * @param {Object} obj Object that should be transformed.
 * @param {String} prefix Optional prefix.
 * @returns {String}
 * @api public
 */
function querystringify(obj, prefix) {
  prefix = prefix || '';

  var pairs = []
    , value
    , key;

  //
  // Optionally prefix with a '?' if needed
  //
  if ('string' !== typeof prefix) prefix = '?';

  for (key in obj) {
    if (has.call(obj, key)) {
      value = obj[key];

      //
      // Edge cases where we actually want to encode the value to an empty
      // string instead of the stringified value.
      //
      if (!value && (value === null || value === undef || isNaN(value))) {
        value = '';
      }

      key = encode(key);
      value = encode(value);

      //
      // If we failed to encode the strings, we should bail out as we don't
      // want to add invalid strings to the query.
      //
      if (key === null || value === null) continue;
      pairs.push(key +'='+ value);
    }
  }

  return pairs.length ? prefix + pairs.join('&') : '';
}

//
// Expose the module.
//
exports.stringify = querystringify;
exports.parse = querystring;


/***/ }),

/***/ "./node_modules/requires-port/index.js":
/*!*********************************************!*\
  !*** ./node_modules/requires-port/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/**
 * Check if we're required to add a port number.
 *
 * @see https://url.spec.whatwg.org/#default-port
 * @param {Number|String} port Port number we need to check
 * @param {String} protocol Protocol we need to check against.
 * @returns {Boolean} Is it a default port for the given protocol
 * @api private
 */
module.exports = function required(port, protocol) {
  protocol = protocol.split(':')[0];
  port = +port;

  if (!port) return false;

  switch (protocol) {
    case 'http':
    case 'ws':
    return port !== 80;

    case 'https':
    case 'wss':
    return port !== 443;

    case 'ftp':
    return port !== 21;

    case 'gopher':
    return port !== 70;

    case 'file':
    return false;
  }

  return port !== 0;
};


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/browser-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/browser-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function parseHexColor(color) {
  // Check the string for incorrect formatting.
  if (!color || color[0] !== '#') {
    if (
      color &&
      typeof color.isKindOfClass === 'function' &&
      color.isKindOfClass(NSColor)
    ) {
      return color
    }
    throw new Error(
      'Incorrect color formating. It should be an hex color: #RRGGBBAA'
    )
  }

  // append FF if alpha channel is not specified.
  var source = color.substr(1)
  if (source.length === 3) {
    source += 'F'
  } else if (source.length === 6) {
    source += 'FF'
  }
  // Convert the string from #FFF format to #FFFFFF format.
  var hex
  if (source.length === 4) {
    for (var i = 0; i < 4; i += 1) {
      hex += source[i]
      hex += source[i]
    }
  } else if (source.length === 8) {
    hex = source
  } else {
    return NSColor.whiteColor()
  }

  var r = parseInt(hex.slice(0, 2), 16) / 255
  var g = parseInt(hex.slice(2, 4), 16) / 255
  var b = parseInt(hex.slice(4, 6), 16) / 255
  var a = parseInt(hex.slice(6, 8), 16) / 255

  return NSColor.colorWithSRGBRed_green_blue_alpha(r, g, b, a)
}

module.exports = function (browserWindow, panel, webview) {
  // keep reference to the subviews
  browserWindow._panel = panel
  browserWindow._webview = webview
  browserWindow._destroyed = false

  browserWindow.destroy = function () {
    return panel.close()
  }

  browserWindow.close = function () {
    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      var shouldClose = true
      browserWindow.emit('close', {
        get defaultPrevented() {
          return !shouldClose
        },
        preventDefault: function () {
          shouldClose = false
        },
      })
      if (shouldClose) {
        panel.delegate().utils.parentWindow.endSheet(panel)
      }
      return
    }

    if (!browserWindow.isClosable()) {
      return
    }

    panel.performClose(null)
  }

  function focus(focused) {
    if (!browserWindow.isVisible()) {
      return
    }
    if (focused) {
      NSApplication.sharedApplication().activateIgnoringOtherApps(true)
      panel.makeKeyAndOrderFront(null)
    } else {
      panel.orderBack(null)
      NSApp.mainWindow().makeKeyAndOrderFront(null)
    }
  }

  browserWindow.focus = focus.bind(this, true)
  browserWindow.blur = focus.bind(this, false)

  browserWindow.isFocused = function () {
    return panel.isKeyWindow()
  }

  browserWindow.isDestroyed = function () {
    return browserWindow._destroyed
  }

  browserWindow.show = function () {
    // This method is supposed to put focus on window, however if the app does not
    // have focus then "makeKeyAndOrderFront" will only show the window.
    NSApp.activateIgnoringOtherApps(true)

    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      return panel.delegate().utils.parentWindow.beginSheet_completionHandler(
        panel,
        __mocha__.createBlock_function('v16@?0q8', function () {
          browserWindow.emit('closed')
        })
      )
    }

    return panel.makeKeyAndOrderFront(null)
  }

  browserWindow.showInactive = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.hide = function () {
    return panel.orderOut(null)
  }

  browserWindow.isVisible = function () {
    return panel.isVisible()
  }

  browserWindow.isModal = function () {
    return false
  }

  browserWindow.maximize = function () {
    if (!browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }
  browserWindow.unmaximize = function () {
    if (browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }

  browserWindow.isMaximized = function () {
    if ((panel.styleMask() & NSResizableWindowMask) !== 0) {
      return panel.isZoomed()
    }
    var rectScreen = NSScreen.mainScreen().visibleFrame()
    var rectWindow = panel.frame()
    return (
      rectScreen.origin.x == rectWindow.origin.x &&
      rectScreen.origin.y == rectWindow.origin.y &&
      rectScreen.size.width == rectWindow.size.width &&
      rectScreen.size.height == rectWindow.size.height
    )
  }

  browserWindow.minimize = function () {
    return panel.miniaturize(null)
  }

  browserWindow.restore = function () {
    return panel.deminiaturize(null)
  }

  browserWindow.isMinimized = function () {
    return panel.isMiniaturized()
  }

  browserWindow.setFullScreen = function (fullscreen) {
    if (fullscreen !== browserWindow.isFullscreen()) {
      panel.toggleFullScreen(null)
    }
  }

  browserWindow.isFullscreen = function () {
    return panel.styleMask() & NSFullScreenWindowMask
  }

  browserWindow.setAspectRatio = function (aspectRatio /* , extraSize */) {
    // Reset the behaviour to default if aspect_ratio is set to 0 or less.
    if (aspectRatio > 0.0) {
      panel.setAspectRatio(NSMakeSize(aspectRatio, 1.0))
    } else {
      panel.setResizeIncrements(NSMakeSize(1.0, 1.0))
    }
  }

  browserWindow.setBounds = function (bounds, animate) {
    if (!bounds) {
      return
    }

    // Do nothing if in fullscreen mode.
    if (browserWindow.isFullscreen()) {
      return
    }

    const newBounds = Object.assign(browserWindow.getBounds(), bounds)

    // TODO: Check size constraints since setFrame does not check it.
    // var size = bounds.size
    // size.SetToMax(GetMinimumSize());
    // gfx::Size max_size = GetMaximumSize();
    // if (!max_size.IsEmpty())
    //   size.SetToMin(max_size);

    var cocoaBounds = NSMakeRect(
      newBounds.x,
      0,
      newBounds.width,
      newBounds.height
    )
    // Flip Y coordinates based on the primary screen
    var screen = NSScreen.screens().firstObject()
    cocoaBounds.origin.y = NSHeight(screen.frame()) - newBounds.y

    panel.setFrame_display_animate(cocoaBounds, true, animate)
  }

  browserWindow.getBounds = function () {
    const cocoaBounds = panel.frame()
    var mainScreenRect = NSScreen.screens().firstObject().frame()
    return {
      x: cocoaBounds.origin.x,
      y: Math.round(NSHeight(mainScreenRect) - cocoaBounds.origin.y),
      width: cocoaBounds.size.width,
      height: cocoaBounds.size.height,
    }
  }

  browserWindow.setContentBounds = function (bounds, animate) {
    // TODO:
    browserWindow.setBounds(bounds, animate)
  }

  browserWindow.getContentBounds = function () {
    // TODO:
    return browserWindow.getBounds()
  }

  browserWindow.setSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setBounds({ width: width, height: height }, animate)
  }

  browserWindow.getSize = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setContentSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setContentBounds(
      { width: width, height: height },
      animate
    )
  }

  browserWindow.getContentSize = function () {
    var bounds = browserWindow.getContentBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setMinimumSize = function (width, height) {
    const minSize = CGSizeMake(width, height)
    panel.setContentMinSize(minSize)
  }

  browserWindow.getMinimumSize = function () {
    const size = panel.contentMinSize()
    return [size.width, size.height]
  }

  browserWindow.setMaximumSize = function (width, height) {
    const maxSize = CGSizeMake(width, height)
    panel.setContentMaxSize(maxSize)
  }

  browserWindow.getMaximumSize = function () {
    const size = panel.contentMaxSize()
    return [size.width, size.height]
  }

  browserWindow.setResizable = function (resizable) {
    return browserWindow._setStyleMask(resizable, NSResizableWindowMask)
  }

  browserWindow.isResizable = function () {
    return panel.styleMask() & NSResizableWindowMask
  }

  browserWindow.setMovable = function (movable) {
    return panel.setMovable(movable)
  }
  browserWindow.isMovable = function () {
    return panel.isMovable()
  }

  browserWindow.setMinimizable = function (minimizable) {
    return browserWindow._setStyleMask(minimizable, NSMiniaturizableWindowMask)
  }

  browserWindow.isMinimizable = function () {
    return panel.styleMask() & NSMiniaturizableWindowMask
  }

  browserWindow.setMaximizable = function (maximizable) {
    if (panel.standardWindowButton(NSWindowZoomButton)) {
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(maximizable)
    }
  }

  browserWindow.isMaximizable = function () {
    return (
      panel.standardWindowButton(NSWindowZoomButton) &&
      panel.standardWindowButton(NSWindowZoomButton).isEnabled()
    )
  }

  browserWindow.setFullScreenable = function (fullscreenable) {
    browserWindow._setCollectionBehavior(
      fullscreenable,
      NSWindowCollectionBehaviorFullScreenPrimary
    )
    // On EL Capitan this flag is required to hide fullscreen button.
    browserWindow._setCollectionBehavior(
      !fullscreenable,
      NSWindowCollectionBehaviorFullScreenAuxiliary
    )
  }

  browserWindow.isFullScreenable = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorFullScreenPrimary
  }

  browserWindow.setClosable = function (closable) {
    browserWindow._setStyleMask(closable, NSClosableWindowMask)
  }

  browserWindow.isClosable = function () {
    return panel.styleMask() & NSClosableWindowMask
  }

  browserWindow.setAlwaysOnTop = function (top, level, relativeLevel) {
    var windowLevel = NSNormalWindowLevel
    var maxWindowLevel = CGWindowLevelForKey(kCGMaximumWindowLevelKey)
    var minWindowLevel = CGWindowLevelForKey(kCGMinimumWindowLevelKey)

    if (top) {
      if (level === 'normal') {
        windowLevel = NSNormalWindowLevel
      } else if (level === 'torn-off-menu') {
        windowLevel = NSTornOffMenuWindowLevel
      } else if (level === 'modal-panel') {
        windowLevel = NSModalPanelWindowLevel
      } else if (level === 'main-menu') {
        windowLevel = NSMainMenuWindowLevel
      } else if (level === 'status') {
        windowLevel = NSStatusWindowLevel
      } else if (level === 'pop-up-menu') {
        windowLevel = NSPopUpMenuWindowLevel
      } else if (level === 'screen-saver') {
        windowLevel = NSScreenSaverWindowLevel
      } else if (level === 'dock') {
        // Deprecated by macOS, but kept for backwards compatibility
        windowLevel = NSDockWindowLevel
      } else {
        windowLevel = NSFloatingWindowLevel
      }
    }

    var newLevel = windowLevel + (relativeLevel || 0)
    if (newLevel >= minWindowLevel && newLevel <= maxWindowLevel) {
      panel.setLevel(newLevel)
    } else {
      throw new Error(
        'relativeLevel must be between ' +
          minWindowLevel +
          ' and ' +
          maxWindowLevel
      )
    }
  }

  browserWindow.isAlwaysOnTop = function () {
    return panel.level() !== NSNormalWindowLevel
  }

  browserWindow.moveTop = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.center = function () {
    panel.center()
  }

  browserWindow.setPosition = function (x, y, animate) {
    return browserWindow.setBounds({ x: x, y: y }, animate)
  }

  browserWindow.getPosition = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.x, bounds.y]
  }

  browserWindow.setTitle = function (title) {
    panel.setTitle(title)
  }

  browserWindow.getTitle = function () {
    return String(panel.title())
  }

  var attentionRequestId = 0
  browserWindow.flashFrame = function (flash) {
    if (flash) {
      attentionRequestId = NSApp.requestUserAttention(NSInformationalRequest)
    } else {
      NSApp.cancelUserAttentionRequest(attentionRequestId)
      attentionRequestId = 0
    }
  }

  browserWindow.getNativeWindowHandle = function () {
    return panel
  }

  browserWindow.getNativeWebViewHandle = function () {
    return webview
  }

  browserWindow.loadURL = function (url) {
    // When frameLocation is a file, prefix it with the Sketch Resources path
    if (/^(?!https?|file).*\.html?$/.test(url)) {
      if (typeof __command !== 'undefined' && __command.pluginBundle()) {
        url =
          'file://' + __command.pluginBundle().urlForResourceNamed(url).path()
      }
    }

    if (/^file:\/\/.*\.html?$/.test(url)) {
      // ensure URLs containing spaces are properly handled
      url = NSString.alloc().initWithString(url)
      url = url.stringByAddingPercentEncodingWithAllowedCharacters(
        NSCharacterSet.URLQueryAllowedCharacterSet()
      )
      webview.loadFileURL_allowingReadAccessToURL(
        NSURL.URLWithString(url),
        NSURL.URLWithString('file:///')
      )
      return
    }

    const properURL = NSURL.URLWithString(url)
    const urlRequest = NSURLRequest.requestWithURL(properURL)

    webview.loadRequest(urlRequest)
  }

  browserWindow.reload = function () {
    webview.reload()
  }

  browserWindow.setHasShadow = function (hasShadow) {
    return panel.setHasShadow(hasShadow)
  }

  browserWindow.hasShadow = function () {
    return panel.hasShadow()
  }

  browserWindow.setOpacity = function (opacity) {
    return panel.setAlphaValue(opacity)
  }

  browserWindow.getOpacity = function () {
    return panel.alphaValue()
  }

  browserWindow.setVisibleOnAllWorkspaces = function (visible) {
    return browserWindow._setCollectionBehavior(
      visible,
      NSWindowCollectionBehaviorCanJoinAllSpaces
    )
  }

  browserWindow.isVisibleOnAllWorkspaces = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorCanJoinAllSpaces
  }

  browserWindow.setIgnoreMouseEvents = function (ignore) {
    return panel.setIgnoresMouseEvents(ignore)
  }

  browserWindow.setContentProtection = function (enable) {
    panel.setSharingType(enable ? NSWindowSharingNone : NSWindowSharingReadOnly)
  }

  browserWindow.setAutoHideCursor = function (autoHide) {
    panel.setDisableAutoHideCursor(autoHide)
  }

  browserWindow.setVibrancy = function (type) {
    var effectView = browserWindow._vibrantView

    if (!type) {
      if (effectView == null) {
        return
      }

      effectView.removeFromSuperview()
      panel.setVibrantView(null)
      return
    }

    if (effectView == null) {
      var contentView = panel.contentView()
      effectView = NSVisualEffectView.alloc().initWithFrame(
        contentView.bounds()
      )
      browserWindow._vibrantView = effectView

      effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
      effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow)
      effectView.setState(NSVisualEffectStateActive)
      effectView.setFrame(contentView.bounds())
      contentView.addSubview_positioned_relativeTo(
        effectView,
        NSWindowBelow,
        null
      )
    }

    var vibrancyType = NSVisualEffectMaterialLight

    if (type === 'appearance-based') {
      vibrancyType = NSVisualEffectMaterialAppearanceBased
    } else if (type === 'light') {
      vibrancyType = NSVisualEffectMaterialLight
    } else if (type === 'dark') {
      vibrancyType = NSVisualEffectMaterialDark
    } else if (type === 'titlebar') {
      vibrancyType = NSVisualEffectMaterialTitlebar
    } else if (type === 'selection') {
      vibrancyType = NSVisualEffectMaterialSelection
    } else if (type === 'menu') {
      vibrancyType = NSVisualEffectMaterialMenu
    } else if (type === 'popover') {
      vibrancyType = NSVisualEffectMaterialPopover
    } else if (type === 'sidebar') {
      vibrancyType = NSVisualEffectMaterialSidebar
    } else if (type === 'medium-light') {
      vibrancyType = NSVisualEffectMaterialMediumLight
    } else if (type === 'ultra-dark') {
      vibrancyType = NSVisualEffectMaterialUltraDark
    }

    effectView.setMaterial(vibrancyType)
  }

  browserWindow._setBackgroundColor = function (colorName) {
    var color = parseHexColor(colorName)
    webview.setValue_forKey(false, 'drawsBackground')
    panel.backgroundColor = color
  }

  browserWindow._invalidate = function () {
    panel.flushWindow()
    panel.contentView().setNeedsDisplay(true)
  }

  browserWindow._setStyleMask = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setStyleMask(panel.styleMask() | flag)
    } else {
      panel.setStyleMask(panel.styleMask() & ~flag)
    }
    // Change style mask will make the zoom button revert to default, probably
    // a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._setCollectionBehavior = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setCollectionBehavior(panel.collectionBehavior() | flag)
    } else {
      panel.setCollectionBehavior(panel.collectionBehavior() & ~flag)
    }
    // Change collectionBehavior will make the zoom button revert to default,
    // probably a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._showWindowButton = function (button) {
    var view = panel.standardWindowButton(button)
    view.superview().addSubview_positioned_relative(view, NSWindowAbove, null)
  }
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/constants.js":
/*!**************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/constants.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  JS_BRIDGE: '__skpm_sketchBridge',
  JS_BRIDGE_RESULT_SUCCESS: '__skpm_sketchBridge_success',
  JS_BRIDGE_RESULT_ERROR: '__skpm_sketchBridge_error',
  START_MOVING_WINDOW: '__skpm_startMovingWindow',
  EXECUTE_JAVASCRIPT: '__skpm_executeJS',
  EXECUTE_JAVASCRIPT_SUCCESS: '__skpm_executeJS_success_',
  EXECUTE_JAVASCRIPT_ERROR: '__skpm_executeJS_error_',
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js":
/*!*************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/dispatch-first-click.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var tagsToFocus =
  '["text", "textarea", "date", "datetime-local", "email", "number", "month", "password", "search", "tel", "time", "url", "week" ]'

module.exports = function (webView, event) {
  var point = webView.convertPoint_fromView(event.locationInWindow(), null)
  return (
    'var el = document.elementFromPoint(' + // get the DOM element that match the event
    point.x +
    ', ' +
    point.y +
    '); ' +
    'if (el && el.tagName === "SELECT") {' + // select needs special handling
    '  var event = document.createEvent("MouseEvents");' +
    '  event.initMouseEvent("mousedown", true, true, window);' +
    '  el.dispatchEvent(event);' +
    '} else if (el && ' + // some tags need to be focused instead of clicked
    tagsToFocus +
    '.indexOf(el.type) >= 0 && ' +
    'el.focus' +
    ') {' +
    'el.focus();' + // so focus them
    '} else if (el) {' +
    'el.dispatchEvent(new Event("click", {bubbles: true}))' + // click the others
    '}'
  )
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/execute-javascript.js":
/*!***********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/execute-javascript.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function (webview, browserWindow) {
  function executeJavaScript(script, userGesture, callback) {
    if (typeof userGesture === 'function') {
      callback = userGesture
      userGesture = false
    }
    var fiber = coscript.createFiber()

    // if the webview is not ready yet, defer the execution until it is
    if (
      webview.navigationDelegate().state &&
      webview.navigationDelegate().state.wasReady == 0
    ) {
      return new Promise(function (resolve, reject) {
        browserWindow.once('ready-to-show', function () {
          executeJavaScript(script, userGesture, callback)
            .then(resolve)
            .catch(reject)
          fiber.cleanup()
        })
      })
    }

    return new Promise(function (resolve, reject) {
      var requestId = Math.random()

      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + requestId,
        function (res) {
          try {
            if (callback) {
              callback(null, res)
            }
            resolve(res)
          } catch (err) {
            reject(err)
          }
          fiber.cleanup()
        }
      )
      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + requestId,
        function (err) {
          try {
            if (callback) {
              callback(err)
              resolve()
            } else {
              reject(err)
            }
          } catch (err2) {
            reject(err2)
          }
          fiber.cleanup()
        }
      )

      webview.evaluateJavaScript_completionHandler(
        module.exports.wrapScript(script, requestId),
        null
      )
    })
  }

  return executeJavaScript
}

module.exports.wrapScript = function (script, requestId) {
  return (
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    '(' +
    requestId +
    ', ' +
    JSON.stringify(script) +
    ')'
  )
}

module.exports.injectScript = function (webView) {
  var source =
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    ' = function(id, script) {' +
    '  try {' +
    '    var res = eval(script);' +
    '    if (res && typeof res.then === "function" && typeof res.catch === "function") {' +
    '      res.then(function (res2) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res2);' +
    '      })' +
    '      .catch(function (err) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '      })' +
    '    } else {' +
    '      window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res);' +
    '    }' +
    '  } catch (err) {' +
    '    window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '  }' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/fitSubview.js":
/*!***************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/fitSubview.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function addEdgeConstraint(edge, subview, view, constant) {
  view.addConstraint(
    NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(
      subview,
      edge,
      NSLayoutRelationEqual,
      view,
      edge,
      1,
      constant
    )
  )
}
module.exports = function fitSubviewToView(subview, view, constants) {
  constants = constants || []
  subview.setTranslatesAutoresizingMaskIntoConstraints(false)

  addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0] || 0)
  addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1] || 0)
  addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2] || 0)
  addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3] || 0)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Browser window
(https://github.com/electron/electron/blob/master/docs/api/browser-window.md) */
var EventEmitter = __webpack_require__(/*! events */ "events")
var buildBrowserAPI = __webpack_require__(/*! ./browser-api */ "./node_modules/sketch-module-web-view/lib/browser-api.js")
var buildWebAPI = __webpack_require__(/*! ./webview-api */ "./node_modules/sketch-module-web-view/lib/webview-api.js")
var fitSubviewToView = __webpack_require__(/*! ./fitSubview */ "./node_modules/sketch-module-web-view/lib/fitSubview.js")
var dispatchFirstClick = __webpack_require__(/*! ./dispatch-first-click */ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js")
var injectClientMessaging = __webpack_require__(/*! ./inject-client-messaging */ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js")
var movableArea = __webpack_require__(/*! ./movable-area */ "./node_modules/sketch-module-web-view/lib/movable-area.js")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")
var setDelegates = __webpack_require__(/*! ./set-delegates */ "./node_modules/sketch-module-web-view/lib/set-delegates.js")

function BrowserWindow(options) {
  options = options || {}

  var identifier = options.identifier || String(NSUUID.UUID().UUIDString())
  var threadDictionary = NSThread.mainThread().threadDictionary()

  var existingBrowserWindow = BrowserWindow.fromId(identifier)

  // if we already have a window opened, reuse it
  if (existingBrowserWindow) {
    return existingBrowserWindow
  }

  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (options.modal && !options.parent) {
    throw new Error('A modal needs to have a parent.')
  }

  // Long-running script
  var fiber = coscript.createFiber()

  // Window size
  var width = options.width || 800
  var height = options.height || 600
  var mainScreenRect = NSScreen.screens().firstObject().frame()
  var cocoaBounds = NSMakeRect(
    typeof options.x !== 'undefined'
      ? options.x
      : Math.round((NSWidth(mainScreenRect) - width) / 2),
    typeof options.y !== 'undefined'
      ? NSHeight(mainScreenRect) - options.y
      : Math.round((NSHeight(mainScreenRect) - height) / 2),
    width,
    height
  )

  if (options.titleBarStyle && options.titleBarStyle !== 'default') {
    options.frame = false
  }

  var useStandardWindow = options.windowType !== 'textured'
  var styleMask = NSTitledWindowMask

  // this is commented out because the toolbar doesn't appear otherwise :thinking-face:
  // if (!useStandardWindow || options.frame === false) {
  //   styleMask = NSFullSizeContentViewWindowMask
  // }
  if (options.minimizable !== false) {
    styleMask |= NSMiniaturizableWindowMask
  }
  if (options.closable !== false) {
    styleMask |= NSClosableWindowMask
  }
  if (options.resizable !== false) {
    styleMask |= NSResizableWindowMask
  }
  if (!useStandardWindow || options.transparent || options.frame === false) {
    styleMask |= NSTexturedBackgroundWindowMask
  }

  var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(
    cocoaBounds,
    styleMask,
    NSBackingStoreBuffered,
    true
  )

  // this would be nice but it's crashing on macOS 11.0
  // panel.releasedWhenClosed = true

  var wkwebviewConfig = WKWebViewConfiguration.alloc().init()
  var webView = WKWebView.alloc().initWithFrame_configuration(
    CGRectMake(0, 0, options.width || 800, options.height || 600),
    wkwebviewConfig
  )
  injectClientMessaging(webView)
  webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)
  setDelegates(browserWindow, panel, webView, options)

  if (options.windowType === 'desktop') {
    panel.setLevel(kCGDesktopWindowLevel - 1)
    // panel.setCanBecomeKeyWindow(false)
    panel.setCollectionBehavior(
      NSWindowCollectionBehaviorCanJoinAllSpaces |
        NSWindowCollectionBehaviorStationary |
        NSWindowCollectionBehaviorIgnoresCycle
    )
  }

  if (
    typeof options.minWidth !== 'undefined' ||
    typeof options.minHeight !== 'undefined'
  ) {
    browserWindow.setMinimumSize(options.minWidth || 0, options.minHeight || 0)
  }

  if (
    typeof options.maxWidth !== 'undefined' ||
    typeof options.maxHeight !== 'undefined'
  ) {
    browserWindow.setMaximumSize(
      options.maxWidth || 10000,
      options.maxHeight || 10000
    )
  }

  // if (options.focusable === false) {
  //   panel.setCanBecomeKeyWindow(false)
  // }

  if (options.transparent || options.frame === false) {
    panel.titlebarAppearsTransparent = true
    panel.titleVisibility = NSWindowTitleHidden
    panel.setOpaque(0)
    panel.isMovableByWindowBackground = true
    var toolbar2 = NSToolbar.alloc().initWithIdentifier(
      'titlebarStylingToolbar'
    )
    toolbar2.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar2)
  }

  if (options.titleBarStyle === 'hiddenInset') {
    var toolbar = NSToolbar.alloc().initWithIdentifier('titlebarStylingToolbar')
    toolbar.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar)
  }

  if (options.frame === false || !options.useContentSize) {
    browserWindow.setSize(width, height)
  }

  if (options.center) {
    browserWindow.center()
  }

  if (options.alwaysOnTop) {
    browserWindow.setAlwaysOnTop(true)
  }

  if (options.fullscreen) {
    browserWindow.setFullScreen(true)
  }
  browserWindow.setFullScreenable(!!options.fullscreenable)

  let title = options.title
  if (options.frame === false) {
    title = undefined
  } else if (
    typeof title === 'undefined' &&
    typeof __command !== 'undefined' &&
    __command.pluginBundle()
  ) {
    title = __command.pluginBundle().name()
  }

  if (title) {
    browserWindow.setTitle(title)
  }

  var backgroundColor = options.backgroundColor
  if (options.transparent) {
    backgroundColor = NSColor.clearColor()
  }
  if (!backgroundColor && options.frame === false && options.vibrancy) {
    backgroundColor = NSColor.clearColor()
  }

  browserWindow._setBackgroundColor(
    backgroundColor || NSColor.windowBackgroundColor()
  )

  if (options.hasShadow === false) {
    browserWindow.setHasShadow(false)
  }

  if (typeof options.opacity !== 'undefined') {
    browserWindow.setOpacity(options.opacity)
  }

  options.webPreferences = options.webPreferences || {}

  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.devTools !== false,
      'developerExtrasEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.javascript !== false,
      'javaScriptEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(!!options.webPreferences.plugins, 'plugInsEnabled')
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.minimumFontSize || 0,
      'minimumFontSize'
    )

  if (options.webPreferences.zoomFactor) {
    webView.setMagnification(options.webPreferences.zoomFactor)
  }

  var contentView = panel.contentView()

  if (options.frame !== false) {
    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)
  } else {
    // In OSX 10.10, adding subviews to the root view for the NSView hierarchy
    // produces warnings. To eliminate the warnings, we resize the contentView
    // to fill the window, and add subviews to that.
    // http://crbug.com/380412
    contentView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
    fitSubviewToView(contentView, contentView.superview())

    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)

    // The fullscreen button should always be hidden for frameless window.
    if (panel.standardWindowButton(NSWindowFullScreenButton)) {
      panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true)
    }

    if (!options.titleBarStyle || options.titleBarStyle === 'default') {
      // Hide the window buttons.
      panel.standardWindowButton(NSWindowZoomButton).setHidden(true)
      panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true)
      panel.standardWindowButton(NSWindowCloseButton).setHidden(true)

      // Some third-party macOS utilities check the zoom button's enabled state to
      // determine whether to show custom UI on hover, so we disable it here to
      // prevent them from doing so in a frameless app window.
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(false)
    }
  }

  if (options.vibrancy) {
    browserWindow.setVibrancy(options.vibrancy)
  }

  // Set maximizable state last to ensure zoom button does not get reset
  // by calls to other APIs.
  browserWindow.setMaximizable(options.maximizable !== false)

  panel.setHidesOnDeactivate(options.hidesOnDeactivate !== false)

  if (options.remembersWindowFrame) {
    panel.setFrameAutosaveName(identifier)
    panel.setFrameUsingName_force(panel.frameAutosaveName(), false)
  }

  if (options.acceptsFirstMouse) {
    browserWindow.on('focus', function (event) {
      if (event.type() === NSEventTypeLeftMouseDown) {
        browserWindow.webContents
          .executeJavaScript(dispatchFirstClick(webView, event))
          .catch(() => {})
      }
    })
  }

  executeJavaScript.injectScript(webView)
  movableArea.injectScript(webView)
  movableArea.setupHandler(browserWindow)

  if (options.show !== false) {
    browserWindow.show()
  }

  browserWindow.on('closed', function () {
    browserWindow._destroyed = true
    threadDictionary.removeObjectForKey(identifier)
    var observer = threadDictionary[identifier + '.themeObserver']
    if (observer) {
      NSApplication.sharedApplication().removeObserver_forKeyPath(
        observer,
        'effectiveAppearance'
      )
      threadDictionary.removeObjectForKey(identifier + '.themeObserver')
    }
    fiber.cleanup()
  })

  threadDictionary[identifier] = panel

  fiber.onCleanup(function () {
    if (!browserWindow._destroyed) {
      browserWindow.destroy()
    }
  })

  return browserWindow
}

BrowserWindow.fromId = function (identifier) {
  var threadDictionary = NSThread.mainThread().threadDictionary()

  if (threadDictionary[identifier]) {
    return BrowserWindow.fromPanel(threadDictionary[identifier], identifier)
  }

  return undefined
}

BrowserWindow.fromPanel = function (panel, identifier) {
  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (!panel || !panel.contentView) {
    throw new Error('needs to pass an NSPanel')
  }

  var webView = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webView &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webView = subviews[i]
    }
  }

  if (!webView) {
    throw new Error('The panel needs to have a webview')
  }

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)

  return browserWindow
}

module.exports = BrowserWindow


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js":
/*!****************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/inject-client-messaging.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function (webView) {
  var source =
    'window.originalPostMessage = window.postMessage;' +
    'window.postMessage = function(actionName) {' +
    '  if (!actionName) {' +
    "    throw new Error('missing action name')" +
    '  }' +
    '  var id = String(Math.random()).replace(".", "");' +
    '    var args = [].slice.call(arguments);' +
    '    args.unshift(id);' +
    '  return new Promise(function (resolve, reject) {' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
    '" + id] = resolve;' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_ERROR +
    '" + id] = reject;' +
    '    window.webkit.messageHandlers.' +
    CONSTANTS.JS_BRIDGE +
    '.postMessage(JSON.stringify(args));' +
    '  });' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/movable-area.js":
/*!*****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/movable-area.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports.injectScript = function (webView) {
  var source =
    '(function () {' +
    "document.addEventListener('mousedown', onMouseDown);" +
    '' +
    'function shouldDrag(target) {' +
    '  if (!target || (target.dataset || {}).appRegion === "no-drag") { return false }' +
    '  if ((target.dataset || {}).appRegion === "drag") { return true }' +
    '  return shouldDrag(target.parentElement)' +
    '};' +
    '' +
    'function onMouseDown(e) {' +
    '  if (e.button !== 0 || !shouldDrag(e.target)) { return }' +
    '  window.postMessage("' +
    CONSTANTS.START_MOVING_WINDOW +
    '");' +
    '};' +
    '})()'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}

module.exports.setupHandler = function (browserWindow) {
  var initialMouseLocation = null
  var initialWindowPosition = null
  var interval = null

  function moveWindow() {
    // if the user released the button, stop moving the window
    if (!initialWindowPosition || NSEvent.pressedMouseButtons() !== 1) {
      clearInterval(interval)
      initialMouseLocation = null
      initialWindowPosition = null
      return
    }

    var mouse = NSEvent.mouseLocation()
    browserWindow.setPosition(
      initialWindowPosition.x + (mouse.x - initialMouseLocation.x),
      initialWindowPosition.y + (initialMouseLocation.y - mouse.y), // y is inverted
      false
    )
  }

  browserWindow.webContents.on(CONSTANTS.START_MOVING_WINDOW, function () {
    initialMouseLocation = NSEvent.mouseLocation()
    var position = browserWindow.getPosition()
    initialWindowPosition = {
      x: position[0],
      y: position[1],
    }

    interval = setInterval(moveWindow, 1000 / 60) // 60 fps
  })
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js":
/*!**********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/parseWebArguments.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (webArguments) {
  var args = null
  try {
    args = JSON.parse(webArguments)
  } catch (e) {
    // malformed arguments
  }

  if (
    !args ||
    !args.constructor ||
    args.constructor !== Array ||
    args.length == 0
  ) {
    return null
  }

  return args
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/set-delegates.js":
/*!******************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/set-delegates.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var ObjCClass = __webpack_require__(/*! mocha-js-delegate */ "./node_modules/mocha-js-delegate/index.js")
var parseWebArguments = __webpack_require__(/*! ./parseWebArguments */ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js")
var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

// We create one ObjC class for ourselves here
var WindowDelegateClass
var NavigationDelegateClass
var WebScriptHandlerClass
var ThemeObserverClass

// TODO: events
// - 'page-favicon-updated'
// - 'new-window'
// - 'did-navigate-in-page'
// - 'will-prevent-unload'
// - 'crashed'
// - 'unresponsive'
// - 'responsive'
// - 'destroyed'
// - 'before-input-event'
// - 'certificate-error'
// - 'found-in-page'
// - 'media-started-playing'
// - 'media-paused'
// - 'did-change-theme-color'
// - 'update-target-url'
// - 'cursor-changed'
// - 'context-menu'
// - 'select-bluetooth-device'
// - 'paint'
// - 'console-message'

module.exports = function (browserWindow, panel, webview, options) {
  if (!ThemeObserverClass) {
    ThemeObserverClass = new ObjCClass({
      utils: null,

      'observeValueForKeyPath:ofObject:change:context:': function (
        keyPath,
        object,
        change
      ) {
        const newAppearance = change[NSKeyValueChangeNewKey]
        const isDark =
          String(
            newAppearance.bestMatchFromAppearancesWithNames([
              'NSAppearanceNameAqua',
              'NSAppearanceNameDarkAqua',
            ])
          ) === 'NSAppearanceNameDarkAqua'

        this.utils.executeJavaScript(
          "document.body.classList.remove('__skpm-" +
            (isDark ? 'light' : 'dark') +
            "'); document.body.classList.add('__skpm-" +
            (isDark ? 'dark' : 'light') +
            "')"
        )
      },
    })
  }

  if (!WindowDelegateClass) {
    WindowDelegateClass = new ObjCClass({
      utils: null,
      panel: null,

      'windowDidResize:': function () {
        this.utils.emit('resize')
      },

      'windowDidMiniaturize:': function () {
        this.utils.emit('minimize')
      },

      'windowDidDeminiaturize:': function () {
        this.utils.emit('restore')
      },

      'windowDidEnterFullScreen:': function () {
        this.utils.emit('enter-full-screen')
      },

      'windowDidExitFullScreen:': function () {
        this.utils.emit('leave-full-screen')
      },

      'windowDidMove:': function () {
        this.utils.emit('move')
        this.utils.emit('moved')
      },

      'windowShouldClose:': function () {
        var shouldClose = 1
        this.utils.emit('close', {
          get defaultPrevented() {
            return !shouldClose
          },
          preventDefault: function () {
            shouldClose = 0
          },
        })
        return shouldClose
      },

      'windowWillClose:': function () {
        this.utils.emit('closed')
      },

      'windowDidBecomeKey:': function () {
        this.utils.emit('focus', this.panel.currentEvent())
      },

      'windowDidResignKey:': function () {
        this.utils.emit('blur')
      },
    })
  }

  if (!NavigationDelegateClass) {
    NavigationDelegateClass = new ObjCClass({
      state: {
        wasReady: 0,
      },
      utils: null,

      // // Called when the web view begins to receive web content.
      'webView:didCommitNavigation:': function (webView) {
        this.utils.emit('will-navigate', {}, String(String(webView.URL())))
      },

      // // Called when web content begins to load in a web view.
      'webView:didStartProvisionalNavigation:': function () {
        this.utils.emit('did-start-navigation')
        this.utils.emit('did-start-loading')
      },

      // Called when a web view receives a server redirect.
      'webView:didReceiveServerRedirectForProvisionalNavigation:': function () {
        this.utils.emit('did-get-redirect-request')
      },

      // // Called when the web view needs to respond to an authentication challenge.
      // 'webView:didReceiveAuthenticationChallenge:completionHandler:': function(
      //   webView,
      //   challenge,
      //   completionHandler
      // ) {
      //   function callback(username, password) {
      //     completionHandler(
      //       0,
      //       NSURLCredential.credentialWithUser_password_persistence(
      //         username,
      //         password,
      //         1
      //       )
      //     )
      //   }
      //   var protectionSpace = challenge.protectionSpace()
      //   this.utils.emit(
      //     'login',
      //     {},
      //     {
      //       method: String(protectionSpace.authenticationMethod()),
      //       url: 'not implemented', // TODO:
      //       referrer: 'not implemented', // TODO:
      //     },
      //     {
      //       isProxy: !!protectionSpace.isProxy(),
      //       scheme: String(protectionSpace.protocol()),
      //       host: String(protectionSpace.host()),
      //       port: Number(protectionSpace.port()),
      //       realm: String(protectionSpace.realm()),
      //     },
      //     callback
      //   )
      // },

      // Called when an error occurs during navigation.
      // 'webView:didFailNavigation:withError:': function(
      //   webView,
      //   navigation,
      //   error
      // ) {},

      // Called when an error occurs while the web view is loading content.
      'webView:didFailProvisionalNavigation:withError:': function (
        webView,
        navigation,
        error
      ) {
        this.utils.emit('did-fail-load', error)
      },

      // Called when the navigation is complete.
      'webView:didFinishNavigation:': function () {
        if (this.state.wasReady == 0) {
          this.state.wasReady = 1
          this.utils.emitBrowserEvent('ready-to-show')
        }
        this.utils.emit('did-navigate')
        this.utils.emit('did-frame-navigate')
        this.utils.emit('did-stop-loading')
        this.utils.emit('did-finish-load')
        this.utils.emit('did-frame-finish-load')
      },

      // Called when the web view’s web content process is terminated.
      'webViewWebContentProcessDidTerminate:': function () {
        this.utils.emit('dom-ready')
      },

      // Decides whether to allow or cancel a navigation.
      // webView:decidePolicyForNavigationAction:decisionHandler:

      // Decides whether to allow or cancel a navigation after its response is known.
      // webView:decidePolicyForNavigationResponse:decisionHandler:
    })
  }

  if (!WebScriptHandlerClass) {
    WebScriptHandlerClass = new ObjCClass({
      utils: null,
      'userContentController:didReceiveScriptMessage:': function (_, message) {
        var args = this.utils.parseWebArguments(String(message.body()))
        if (!args) {
          return
        }
        if (!args[0] || typeof args[0] !== 'string') {
          return
        }
        args[0] = String(args[0])

        this.utils.emit.apply(this, args)
      },
    })
  }

  var themeObserver = ThemeObserverClass.new({
    utils: {
      executeJavaScript(script) {
        webview.evaluateJavaScript_completionHandler(script, null)
      },
    },
  })

  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    "document.addEventListener('DOMContentLoaded', function() { document.body.classList.add('__skpm-" +
      (typeof MSTheme !== 'undefined' && MSTheme.sharedTheme().isDark()
        ? 'dark'
        : 'light') +
      "') }, false)",
    0,
    true
  )
  webview.configuration().userContentController().addUserScript(script)

  NSApplication.sharedApplication().addObserver_forKeyPath_options_context(
    themeObserver,
    'effectiveAppearance',
    NSKeyValueObservingOptionNew,
    null
  )

  var threadDictionary = NSThread.mainThread().threadDictionary()
  threadDictionary[browserWindow.id + '.themeObserver'] = themeObserver

  var navigationDelegate = NavigationDelegateClass.new({
    utils: {
      setTitle: browserWindow.setTitle.bind(browserWindow),
      emitBrowserEvent() {
        try {
          browserWindow.emit.apply(browserWindow, arguments)
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
      emit() {
        try {
          browserWindow.webContents.emit.apply(
            browserWindow.webContents,
            arguments
          )
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
    },
    state: {
      wasReady: 0,
    },
  })

  webview.setNavigationDelegate(navigationDelegate)

  var webScriptHandler = WebScriptHandlerClass.new({
    utils: {
      emit(id, type) {
        if (!type) {
          webview.evaluateJavaScript_completionHandler(
            CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + id + '()',
            null
          )
          return
        }

        var args = []
        for (var i = 2; i < arguments.length; i += 1) args.push(arguments[i])

        var listeners = browserWindow.webContents.listeners(type)

        Promise.all(
          listeners.map(function (l) {
            return Promise.resolve().then(function () {
              return l.apply(l, args)
            })
          })
        )
          .then(function (res) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
                id +
                '(' +
                JSON.stringify(res) +
                ')',
              null
            )
          })
          .catch(function (err) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_ERROR +
                id +
                '(' +
                JSON.stringify(err) +
                ')',
              null
            )
          })
      },
      parseWebArguments: parseWebArguments,
    },
  })

  webview
    .configuration()
    .userContentController()
    .addScriptMessageHandler_name(webScriptHandler, CONSTANTS.JS_BRIDGE)

  var utils = {
    emit() {
      try {
        browserWindow.emit.apply(browserWindow, arguments)
      } catch (err) {
        if (
          typeof process !== 'undefined' &&
          process.listenerCount &&
          process.listenerCount('uncaughtException')
        ) {
          process.emit('uncaughtException', err, 'uncaughtException')
        } else {
          console.error(err)
          throw err
        }
      }
    },
  }
  if (options.modal) {
    // find the window of the document
    var msdocument
    if (options.parent.type === 'Document') {
      msdocument = options.parent.sketchObject
    } else {
      msdocument = options.parent
    }
    if (msdocument && String(msdocument.class()) === 'MSDocumentData') {
      // we only have an MSDocumentData instead of a MSDocument
      // let's try to get back to the MSDocument
      msdocument = msdocument.delegate()
    }
    utils.parentWindow = msdocument.windowForSheet()
  }

  var windowDelegate = WindowDelegateClass.new({
    utils: utils,
    panel: panel,
  })

  panel.setDelegate(windowDelegate)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/webview-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/webview-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var EventEmitter = __webpack_require__(/*! events */ "events")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")

// let's try to match https://github.com/electron/electron/blob/master/docs/api/web-contents.md
module.exports = function buildAPI(browserWindow, panel, webview) {
  var webContents = new EventEmitter()

  webContents.loadURL = browserWindow.loadURL

  webContents.loadFile = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.downloadURL = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.getURL = function () {
    return String(webview.URL())
  }

  webContents.getTitle = function () {
    return String(webview.title())
  }

  webContents.isDestroyed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.focus = browserWindow.focus
  webContents.isFocused = browserWindow.isFocused

  webContents.isLoading = function () {
    return !!webview.loading()
  }

  webContents.isLoadingMainFrame = function () {
    // TODO:
    return !!webview.loading()
  }

  webContents.isWaitingForResponse = function () {
    return !webview.loading()
  }

  webContents.stop = function () {
    webview.stopLoading()
  }
  webContents.reload = function () {
    webview.reload()
  }
  webContents.reloadIgnoringCache = function () {
    webview.reloadFromOrigin()
  }
  webContents.canGoBack = function () {
    return !!webview.canGoBack()
  }
  webContents.canGoForward = function () {
    return !!webview.canGoForward()
  }
  webContents.canGoToOffset = function (offset) {
    return !!webview.backForwardList().itemAtIndex(offset)
  }
  webContents.clearHistory = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.goBack = function () {
    webview.goBack()
  }
  webContents.goForward = function () {
    webview.goForward()
  }
  webContents.goToIndex = function (index) {
    var backForwardList = webview.backForwardList()
    var backList = backForwardList.backList()
    var backListLength = backList.count()
    if (backListLength > index) {
      webview.loadRequest(NSURLRequest.requestWithURL(backList[index]))
      return
    }
    var forwardList = backForwardList.forwardList()
    if (forwardList.count() > index - backListLength) {
      webview.loadRequest(
        NSURLRequest.requestWithURL(forwardList[index - backListLength])
      )
      return
    }
    throw new Error('Cannot go to index ' + index)
  }
  webContents.goToOffset = function (offset) {
    if (!webContents.canGoToOffset(offset)) {
      throw new Error('Cannot go to offset ' + offset)
    }
    webview.loadRequest(
      NSURLRequest.requestWithURL(webview.backForwardList().itemAtIndex(offset))
    )
  }
  webContents.isCrashed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setUserAgent = function (/* userAgent */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.getUserAgent = function () {
    const userAgent = webview.customUserAgent()
    return userAgent ? String(userAgent) : undefined
  }
  webContents.insertCSS = function (css) {
    var source =
      "var style = document.createElement('style'); style.innerHTML = " +
      css.replace(/"/, '\\"') +
      '; document.head.appendChild(style);'
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.insertJS = function (source) {
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.executeJavaScript = executeJavaScript(webview, browserWindow)
  webContents.setIgnoreMenuShortcuts = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setAudioMuted = function (/* muted */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.isAudioMuted = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setZoomFactor = function (factor) {
    webview.setMagnification_centeredAtPoint(factor, CGPointMake(0, 0))
  }
  webContents.getZoomFactor = function (callback) {
    callback(Number(webview.magnification()))
  }
  webContents.setZoomLevel = function (level) {
    // eslint-disable-next-line no-restricted-properties
    webContents.setZoomFactor(Math.pow(1.2, level))
  }
  webContents.getZoomLevel = function (callback) {
    // eslint-disable-next-line no-restricted-properties
    callback(Math.log(Number(webview.magnification())) / Math.log(1.2))
  }
  webContents.setVisualZoomLevelLimits = function (/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setLayoutZoomLevelLimits = function (/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  // TODO:
  // webContents.undo = function() {
  //   webview.undoManager().undo()
  // }
  // webContents.redo = function() {
  //   webview.undoManager().redo()
  // }
  // webContents.cut = webview.cut
  // webContents.copy = webview.copy
  // webContents.paste = webview.paste
  // webContents.pasteAndMatchStyle = webview.pasteAsRichText
  // webContents.delete = webview.delete
  // webContents.replace = webview.replaceSelectionWithText

  webContents.send = function () {
    const script =
      'window.postMessage({' +
      'isSketchMessage: true,' +
      "origin: '" +
      String(__command.identifier()) +
      "'," +
      'args: ' +
      JSON.stringify([].slice.call(arguments)) +
      '}, "*")'
    webview.evaluateJavaScript_completionHandler(script, null)
  }

  webContents.getNativeWebview = function () {
    return webview
  }

  browserWindow.webContents = webContents
}


/***/ }),

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var error;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          error
        );
        if (error != null) {
          return reject(error);
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, error) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          if (error) {
            finished = true;
            return reject(error);
          }
          return resolve(response(res, data));
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/url-parse/index.js":
/*!*****************************************!*\
  !*** ./node_modules/url-parse/index.js ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var required = __webpack_require__(/*! requires-port */ "./node_modules/requires-port/index.js")
  , qs = __webpack_require__(/*! querystringify */ "./node_modules/querystringify/index.js")
  , slashes = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//
  , protocolre = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\\/]+)?([\S\s]*)/i
  , windowsDriveLetter = /^[a-zA-Z]:/
  , whitespace = '[\\x09\\x0A\\x0B\\x0C\\x0D\\x20\\xA0\\u1680\\u180E\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200A\\u202F\\u205F\\u3000\\u2028\\u2029\\uFEFF]'
  , left = new RegExp('^'+ whitespace +'+');

/**
 * Trim a given string.
 *
 * @param {String} str String to trim.
 * @public
 */
function trimLeft(str) {
  return (str ? str : '').toString().replace(left, '');
}

/**
 * These are the parse rules for the URL parser, it informs the parser
 * about:
 *
 * 0. The char it Needs to parse, if it's a string it should be done using
 *    indexOf, RegExp using exec and NaN means set as current value.
 * 1. The property we should set when parsing this value.
 * 2. Indication if it's backwards or forward parsing, when set as number it's
 *    the value of extra chars that should be split off.
 * 3. Inherit from location if non existing in the parser.
 * 4. `toLowerCase` the resulting value.
 */
var rules = [
  ['#', 'hash'],                        // Extract from the back.
  ['?', 'query'],                       // Extract from the back.
  function sanitize(address, url) {     // Sanitize what is left of the address
    return isSpecial(url.protocol) ? address.replace(/\\/g, '/') : address;
  },
  ['/', 'pathname'],                    // Extract from the back.
  ['@', 'auth', 1],                     // Extract from the front.
  [NaN, 'host', undefined, 1, 1],       // Set left over value.
  [/:(\d+)$/, 'port', undefined, 1],    // RegExp the back.
  [NaN, 'hostname', undefined, 1, 1]    // Set left over.
];

/**
 * These properties should not be copied or inherited from. This is only needed
 * for all non blob URL's as a blob URL does not include a hash, only the
 * origin.
 *
 * @type {Object}
 * @private
 */
var ignore = { hash: 1, query: 1 };

/**
 * The location object differs when your code is loaded through a normal page,
 * Worker or through a worker using a blob. And with the blobble begins the
 * trouble as the location object will contain the URL of the blob, not the
 * location of the page where our code is loaded in. The actual origin is
 * encoded in the `pathname` so we can thankfully generate a good "default"
 * location from it so we can generate proper relative URL's again.
 *
 * @param {Object|String} loc Optional default location object.
 * @returns {Object} lolcation object.
 * @public
 */
function lolcation(loc) {
  var globalVar;

  if (typeof window !== 'undefined') globalVar = window;
  else if (typeof global !== 'undefined') globalVar = global;
  else if (typeof self !== 'undefined') globalVar = self;
  else globalVar = {};

  var location = globalVar.location || {};
  loc = loc || location;

  var finaldestination = {}
    , type = typeof loc
    , key;

  if ('blob:' === loc.protocol) {
    finaldestination = new Url(unescape(loc.pathname), {});
  } else if ('string' === type) {
    finaldestination = new Url(loc, {});
    for (key in ignore) delete finaldestination[key];
  } else if ('object' === type) {
    for (key in loc) {
      if (key in ignore) continue;
      finaldestination[key] = loc[key];
    }

    if (finaldestination.slashes === undefined) {
      finaldestination.slashes = slashes.test(loc.href);
    }
  }

  return finaldestination;
}

/**
 * Check whether a protocol scheme is special.
 *
 * @param {String} The protocol scheme of the URL
 * @return {Boolean} `true` if the protocol scheme is special, else `false`
 * @private
 */
function isSpecial(scheme) {
  return (
    scheme === 'file:' ||
    scheme === 'ftp:' ||
    scheme === 'http:' ||
    scheme === 'https:' ||
    scheme === 'ws:' ||
    scheme === 'wss:'
  );
}

/**
 * @typedef ProtocolExtract
 * @type Object
 * @property {String} protocol Protocol matched in the URL, in lowercase.
 * @property {Boolean} slashes `true` if protocol is followed by "//", else `false`.
 * @property {String} rest Rest of the URL that is not part of the protocol.
 */

/**
 * Extract protocol information from a URL with/without double slash ("//").
 *
 * @param {String} address URL we want to extract from.
 * @param {Object} location
 * @return {ProtocolExtract} Extracted information.
 * @private
 */
function extractProtocol(address, location) {
  address = trimLeft(address);
  location = location || {};

  var match = protocolre.exec(address);
  var protocol = match[1] ? match[1].toLowerCase() : '';
  var forwardSlashes = !!match[2];
  var otherSlashes = !!match[3];
  var slashesCount = 0;
  var rest;

  if (forwardSlashes) {
    if (otherSlashes) {
      rest = match[2] + match[3] + match[4];
      slashesCount = match[2].length + match[3].length;
    } else {
      rest = match[2] + match[4];
      slashesCount = match[2].length;
    }
  } else {
    if (otherSlashes) {
      rest = match[3] + match[4];
      slashesCount = match[3].length;
    } else {
      rest = match[4]
    }
  }

  if (protocol === 'file:') {
    if (slashesCount >= 2) {
      rest = rest.slice(2);
    }
  } else if (isSpecial(protocol)) {
    rest = match[4];
  } else if (protocol) {
    if (forwardSlashes) {
      rest = rest.slice(2);
    }
  } else if (slashesCount >= 2 && isSpecial(location.protocol)) {
    rest = match[4];
  }

  return {
    protocol: protocol,
    slashes: forwardSlashes || isSpecial(protocol),
    slashesCount: slashesCount,
    rest: rest
  };
}

/**
 * Resolve a relative URL pathname against a base URL pathname.
 *
 * @param {String} relative Pathname of the relative URL.
 * @param {String} base Pathname of the base URL.
 * @return {String} Resolved pathname.
 * @private
 */
function resolve(relative, base) {
  if (relative === '') return base;

  var path = (base || '/').split('/').slice(0, -1).concat(relative.split('/'))
    , i = path.length
    , last = path[i - 1]
    , unshift = false
    , up = 0;

  while (i--) {
    if (path[i] === '.') {
      path.splice(i, 1);
    } else if (path[i] === '..') {
      path.splice(i, 1);
      up++;
    } else if (up) {
      if (i === 0) unshift = true;
      path.splice(i, 1);
      up--;
    }
  }

  if (unshift) path.unshift('');
  if (last === '.' || last === '..') path.push('');

  return path.join('/');
}

/**
 * The actual URL instance. Instead of returning an object we've opted-in to
 * create an actual constructor as it's much more memory efficient and
 * faster and it pleases my OCD.
 *
 * It is worth noting that we should not use `URL` as class name to prevent
 * clashes with the global URL instance that got introduced in browsers.
 *
 * @constructor
 * @param {String} address URL we want to parse.
 * @param {Object|String} [location] Location defaults for relative paths.
 * @param {Boolean|Function} [parser] Parser for the query string.
 * @private
 */
function Url(address, location, parser) {
  address = trimLeft(address);

  if (!(this instanceof Url)) {
    return new Url(address, location, parser);
  }

  var relative, extracted, parse, instruction, index, key
    , instructions = rules.slice()
    , type = typeof location
    , url = this
    , i = 0;

  //
  // The following if statements allows this module two have compatibility with
  // 2 different API:
  //
  // 1. Node.js's `url.parse` api which accepts a URL, boolean as arguments
  //    where the boolean indicates that the query string should also be parsed.
  //
  // 2. The `URL` interface of the browser which accepts a URL, object as
  //    arguments. The supplied object will be used as default values / fall-back
  //    for relative paths.
  //
  if ('object' !== type && 'string' !== type) {
    parser = location;
    location = null;
  }

  if (parser && 'function' !== typeof parser) parser = qs.parse;

  location = lolcation(location);

  //
  // Extract protocol information before running the instructions.
  //
  extracted = extractProtocol(address || '', location);
  relative = !extracted.protocol && !extracted.slashes;
  url.slashes = extracted.slashes || relative && location.slashes;
  url.protocol = extracted.protocol || location.protocol || '';
  address = extracted.rest;

  //
  // When the authority component is absent the URL starts with a path
  // component.
  //
  if (
    extracted.protocol === 'file:' && (
      extracted.slashesCount !== 2 || windowsDriveLetter.test(address)) ||
    (!extracted.slashes &&
      (extracted.protocol ||
        extracted.slashesCount < 2 ||
        !isSpecial(url.protocol)))
  ) {
    instructions[3] = [/(.*)/, 'pathname'];
  }

  for (; i < instructions.length; i++) {
    instruction = instructions[i];

    if (typeof instruction === 'function') {
      address = instruction(address, url);
      continue;
    }

    parse = instruction[0];
    key = instruction[1];

    if (parse !== parse) {
      url[key] = address;
    } else if ('string' === typeof parse) {
      if (~(index = address.indexOf(parse))) {
        if ('number' === typeof instruction[2]) {
          url[key] = address.slice(0, index);
          address = address.slice(index + instruction[2]);
        } else {
          url[key] = address.slice(index);
          address = address.slice(0, index);
        }
      }
    } else if ((index = parse.exec(address))) {
      url[key] = index[1];
      address = address.slice(0, index.index);
    }

    url[key] = url[key] || (
      relative && instruction[3] ? location[key] || '' : ''
    );

    //
    // Hostname, host and protocol should be lowercased so they can be used to
    // create a proper `origin`.
    //
    if (instruction[4]) url[key] = url[key].toLowerCase();
  }

  //
  // Also parse the supplied query string in to an object. If we're supplied
  // with a custom parser as function use that instead of the default build-in
  // parser.
  //
  if (parser) url.query = parser(url.query);

  //
  // If the URL is relative, resolve the pathname against the base URL.
  //
  if (
      relative
    && location.slashes
    && url.pathname.charAt(0) !== '/'
    && (url.pathname !== '' || location.pathname !== '')
  ) {
    url.pathname = resolve(url.pathname, location.pathname);
  }

  //
  // Default to a / for pathname if none exists. This normalizes the URL
  // to always have a /
  //
  if (url.pathname.charAt(0) !== '/' && isSpecial(url.protocol)) {
    url.pathname = '/' + url.pathname;
  }

  //
  // We should not add port numbers if they are already the default port number
  // for a given protocol. As the host also contains the port number we're going
  // override it with the hostname which contains no port number.
  //
  if (!required(url.port, url.protocol)) {
    url.host = url.hostname;
    url.port = '';
  }

  //
  // Parse down the `auth` for the username and password.
  //
  url.username = url.password = '';
  if (url.auth) {
    instruction = url.auth.split(':');
    url.username = instruction[0] || '';
    url.password = instruction[1] || '';
  }

  url.origin = url.protocol !== 'file:' && isSpecial(url.protocol) && url.host
    ? url.protocol +'//'+ url.host
    : 'null';

  //
  // The href is just the compiled result.
  //
  url.href = url.toString();
}

/**
 * This is convenience method for changing properties in the URL instance to
 * insure that they all propagate correctly.
 *
 * @param {String} part          Property we need to adjust.
 * @param {Mixed} value          The newly assigned value.
 * @param {Boolean|Function} fn  When setting the query, it will be the function
 *                               used to parse the query.
 *                               When setting the protocol, double slash will be
 *                               removed from the final url if it is true.
 * @returns {URL} URL instance for chaining.
 * @public
 */
function set(part, value, fn) {
  var url = this;

  switch (part) {
    case 'query':
      if ('string' === typeof value && value.length) {
        value = (fn || qs.parse)(value);
      }

      url[part] = value;
      break;

    case 'port':
      url[part] = value;

      if (!required(value, url.protocol)) {
        url.host = url.hostname;
        url[part] = '';
      } else if (value) {
        url.host = url.hostname +':'+ value;
      }

      break;

    case 'hostname':
      url[part] = value;

      if (url.port) value += ':'+ url.port;
      url.host = value;
      break;

    case 'host':
      url[part] = value;

      if (/:\d+$/.test(value)) {
        value = value.split(':');
        url.port = value.pop();
        url.hostname = value.join(':');
      } else {
        url.hostname = value;
        url.port = '';
      }

      break;

    case 'protocol':
      url.protocol = value.toLowerCase();
      url.slashes = !fn;
      break;

    case 'pathname':
    case 'hash':
      if (value) {
        var char = part === 'pathname' ? '/' : '#';
        url[part] = value.charAt(0) !== char ? char + value : value;
      } else {
        url[part] = value;
      }
      break;

    default:
      url[part] = value;
  }

  for (var i = 0; i < rules.length; i++) {
    var ins = rules[i];

    if (ins[4]) url[ins[1]] = url[ins[1]].toLowerCase();
  }

  url.origin = url.protocol !== 'file:' && isSpecial(url.protocol) && url.host
    ? url.protocol +'//'+ url.host
    : 'null';

  url.href = url.toString();

  return url;
}

/**
 * Transform the properties back in to a valid and full URL string.
 *
 * @param {Function} stringify Optional query stringify function.
 * @returns {String} Compiled version of the URL.
 * @public
 */
function toString(stringify) {
  if (!stringify || 'function' !== typeof stringify) stringify = qs.stringify;

  var query
    , url = this
    , protocol = url.protocol;

  if (protocol && protocol.charAt(protocol.length - 1) !== ':') protocol += ':';

  var result = protocol + (url.slashes || isSpecial(url.protocol) ? '//' : '');

  if (url.username) {
    result += url.username;
    if (url.password) result += ':'+ url.password;
    result += '@';
  }

  result += url.host + url.pathname;

  query = 'object' === typeof url.query ? stringify(url.query) : url.query;
  if (query) result += '?' !== query.charAt(0) ? '?'+ query : query;

  if (url.hash) result += url.hash;

  return result;
}

Url.prototype = { set: set, toString: toString };

//
// Expose the URL parser and some additional properties that might be useful for
// others or testing.
//
Url.extractProtocol = extractProtocol;
Url.location = lolcation;
Url.trimLeft = trimLeft;
Url.qs = qs;

module.exports = Url;


/***/ }),

/***/ "./src/config.js":
/*!***********************!*\
  !*** ./src/config.js ***!
  \***********************/
/*! exports provided: prefix, topBarHeight, SIDE_PANEL_WIDTH, BORDER_WIDTH, SKETCH_HIGHEST_COMPATIBLE_VERSION, IS_SHOW_SKETCH, minWidth, minHeight, SKETCH_INSPECTOR */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "prefix", function() { return prefix; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "topBarHeight", function() { return topBarHeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SIDE_PANEL_WIDTH", function() { return SIDE_PANEL_WIDTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BORDER_WIDTH", function() { return BORDER_WIDTH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SKETCH_HIGHEST_COMPATIBLE_VERSION", function() { return SKETCH_HIGHEST_COMPATIBLE_VERSION; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IS_SHOW_SKETCH", function() { return IS_SHOW_SKETCH; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "minWidth", function() { return minWidth; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "minHeight", function() { return minHeight; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SKETCH_INSPECTOR", function() { return SKETCH_INSPECTOR; });
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_0__);
 // export const prefix = 'https://sg.music.163.com/dolphin-client';

var prefix = 'http://localhost:8000';
var topBarHeight = Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) >= 70 ? 40 : 0;
var SIDE_PANEL_WIDTH = 50;
var BORDER_WIDTH = 1;
var SKETCH_HIGHEST_COMPATIBLE_VERSION = '136';
var IS_SHOW_SKETCH = 'is_show_dolphin_sketch_plugin';
var minWidth = 238;
var minHeight = 400;
var SKETCH_INSPECTOR = 'SKETCH_INSPECTOR';

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! exports provided: onToggleSidePanel, onCloseDocument, onShutdown, onStartup, onSelectionChanged, onCopy, onPaste, fixSingleLineLineHeight */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onToggleSidePanel", function() { return onToggleSidePanel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onCloseDocument", function() { return onCloseDocument; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onStartup", function() { return onStartup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSelectionChanged", function() { return onSelectionChanged; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onCopy", function() { return onCopy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onPaste", function() { return onPaste; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fixSingleLineLineHeight", function() { return fixSingleLineLineHeight; });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch/settings */ "sketch/settings");
/* harmony import */ var sketch_settings__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_settings__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! sketch-module-web-view */ "./node_modules/sketch-module-web-view/lib/index.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_apm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./utils/apm */ "./src/utils/apm.js");
/* harmony import */ var _utils_injectcolorToken__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./utils/injectcolorToken */ "./src/utils/injectcolorToken.js");
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./state */ "./src/state.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./utils */ "./src/utils/index.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./config */ "./src/config.js");
/* harmony import */ var _utils_displayErrorMessage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./utils/displayErrorMessage */ "./src/utils/displayErrorMessage.js");
/* harmony import */ var _utils_renderCom__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./utils/renderCom */ "./src/utils/renderCom.js");
/* harmony import */ var _tabviewController__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./tabviewController */ "./src/tabviewController.js");
/* harmony import */ var _webview_sidePanel__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./webview/sidePanel */ "./src/webview/sidePanel.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }














 // Long-running script

var fiber = coscript.createFiber();

function setIsDrag(isDrag) {
  sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setSessionVariable('isDrag', isDrag);
}

function renderComponent(args) {
  try {
    args = JSON.parse(args);
  } catch (error) {
    args = {};
  }

  Object(_utils_renderCom__WEBPACK_IMPORTED_MODULE_12__["default"])(args, _state__WEBPACK_IMPORTED_MODULE_8__["context"]);
}

function showStatePanel() {
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var statePanel = threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"]];
  statePanel && Object(_utils__WEBPACK_IMPORTED_MODULE_9__["insertItemToSplitViewAtIndex"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"], statePanel, Object(_utils__WEBPACK_IMPORTED_MODULE_9__["getSplitViewItemIndexForSketchInspector"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"]) - 1);
}

function hideStatePanel() {
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var statePanel = threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"]];
  statePanel && Object(_utils__WEBPACK_IMPORTED_MODULE_9__["removeItemFromSplitView"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"], statePanel);
}
/**
 * insertSidePanel 插入侧边栏
 * @param {*} toolbar
 * @param {*} identifier
 * @param {*} isInsert  默认插入，已插入删除
 */


var insertSidePanel = function insertSidePanel() {
  var splitViewController = _state__WEBPACK_IMPORTED_MODULE_8__["context"].document.splitViewController();
  var threadDictionary = NSThread.mainThread().threadDictionary();

  try {
    // 侧边工具栏
    var toolbarViewController = NSViewController.alloc().init();
    var toolbarBrowser = new sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5___default.a({
      width: _config__WEBPACK_IMPORTED_MODULE_10__["SIDE_PANEL_WIDTH"],
      height: 400,
      minimizable: false,
      resizable: true,
      transparent: false,
      closable: false,
      center: false,
      alwaysOnTop: true,
      titleBarStyle: 'hiddenInset',
      frame: false,
      show: false,
      hasShadow: false,
      remembersWindowFrame: true,
      acceptsFirstMouse: true
    });
    toolbarBrowser.loadURL("".concat(_config__WEBPACK_IMPORTED_MODULE_10__["prefix"], "/main-menu"));
    toolbarBrowser.identifier = _state__WEBPACK_IMPORTED_MODULE_8__["toolBarViewIdentifier"];
    threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["toolBarViewIdentifier"]] = toolbarBrowser;
    toolbarViewController.view = toolbarBrowser._webview;

    var runCommand = function runCommand(params) {
      try {
        try {
          params = JSON.parse(params);
        } catch (error) {
          params = {};
        }

        var _params = params,
            command = _params.command,
            name = _params.name,
            router = _params.router;

        switch (command) {
          case 'route':
            {
              if (name === 'sketch') {
                Object(_tabviewController__WEBPACK_IMPORTED_MODULE_13__["selectTabItemById"])(_config__WEBPACK_IMPORTED_MODULE_10__["SKETCH_INSPECTOR"]);
                return;
              }

              var currentMenu = _state__WEBPACK_IMPORTED_MODULE_8__["Menus"].find(function (item) {
                return item.name === name;
              });
              toolbarBrowser.webContents.executeJavaScript("setCurrentMenu(".concat(JSON.stringify({
                menu: name
              }), ")"));
              var options = {
                identifier: currentMenu.identifier,
                frame: false,
                show: false,
                width: 320,
                height: 480,
                url: router ? "".concat(_config__WEBPACK_IMPORTED_MODULE_10__["prefix"]).concat(router) : currentMenu.url,
                name: name,
                document: _state__WEBPACK_IMPORTED_MODULE_8__["document"],
                runCommand: runCommand
              };

              var _SideBrowser = new _webview_sidePanel__WEBPACK_IMPORTED_MODULE_14__["Browser"](options),
                  browserWindow = _SideBrowser.browserWindow;

              var webContents = browserWindow.webContents;
              webContents.removeListener('setIsDrag', setIsDrag);
              webContents.on('setIsDrag', setIsDrag);
              webContents.removeListener('renderComponent', renderComponent);
              webContents.on('renderComponent', renderComponent);
              webContents.removeListener('displayErrorMessage', _utils_displayErrorMessage__WEBPACK_IMPORTED_MODULE_11__["default"]);
              webContents.on('displayErrorMessage', _utils_displayErrorMessage__WEBPACK_IMPORTED_MODULE_11__["default"]);
              webContents.removeListener('runCommand', runCommand);
              webContents.on('runCommand', runCommand);
              Object(_tabviewController__WEBPACK_IMPORTED_MODULE_13__["addWebViewToTab"])(browserWindow);
              Object(_tabviewController__WEBPACK_IMPORTED_MODULE_13__["selectTabItemById"])(currentMenu.identifier);
              break;
            }

          case 'setCurrentMenu':
            {
              toolbarBrowser.webContents.executeJavaScript("setCurrentMenu(".concat(JSON.stringify({
                menu: name
              }), ")"));
              break;
            }

          default:
        }

        try {
          // 每日使用打点
          var today = new Date().toISOString().slice(0, 10);

          if (Object(_utils__WEBPACK_IMPORTED_MODULE_9__["getSettingForKey"])('lastUseDate') != today) {
            Object(_utils_apm__WEBPACK_IMPORTED_MODULE_6__["logDailyUseage"])(function () {
              Object(_utils__WEBPACK_IMPORTED_MODULE_9__["setSettingForKey"])('lastUseDate', today);
            });
          }
        } catch (error) {
          console.log(error);
        }
      } catch (error) {
        console.log(error);
      }
    };

    toolbarBrowser.webContents.on('runCommand', runCommand); // Make a split view item

    var toolbarView = NSSplitViewItem.splitViewItemWithViewController(toolbarViewController);
    toolbarView.identifier = _state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"];
    threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"]] = toolbarView;
    toolbarView.maximumThickness = 50;
    toolbarView.minimumThickness = 50;
    toolbarView.collapsed = true;
    toolbarView.collapsed = false;
    Object(_utils__WEBPACK_IMPORTED_MODULE_9__["insertItemToSplitViewAtIndex"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"], toolbarView, Object(_utils__WEBPACK_IMPORTED_MODULE_9__["getSplitViewItemIndexForSketchInspector"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"])); // 配置面板

    var statePanelViewController = NSViewController.alloc().init();
    var statePanelView = new sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5___default.a({
      width: 220,
      height: 400,
      minimizable: false,
      resizable: false,
      transparent: false,
      closable: false,
      center: false,
      alwaysOnTop: true,
      titleBarStyle: 'hiddenInset',
      hidesOnDeactivate: false,
      frame: false,
      show: false,
      hasShadow: false,
      movable: false,
      acceptsFirstMouse: true
    });
    statePanelView.loadURL("".concat(_config__WEBPACK_IMPORTED_MODULE_10__["prefix"], "/state-panel"));
    statePanelView.setMovable(false);
    statePanelViewController.view = statePanelView._webview;
    statePanelView.identifier = _state__WEBPACK_IMPORTED_MODULE_8__["statePanelViewIdentifier"];
    threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["statePanelViewIdentifier"]] = statePanelView;
    statePanelView.webContents.on('renderComponent', function (params) {
      var rl = {};

      try {
        rl = JSON.parse(params);
      } catch (error) {
        rl = {};
      }

      Object(_utils_renderCom__WEBPACK_IMPORTED_MODULE_12__["default"])(rl, _state__WEBPACK_IMPORTED_MODULE_8__["context"]);
    });
    statePanelView.webContents.on('displayErrorMessage', _utils_displayErrorMessage__WEBPACK_IMPORTED_MODULE_11__["default"]);
    statePanelView.webContents.on('closePage', function () {
      console.info('Start Close StatePanel.');

      if (threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"]]) {
        hideStatePanel();
      }

      console.info('Finish Close StatePanel.');
    }); // Make a split view item

    var statePanel = NSSplitViewItem.splitViewItemWithViewController(statePanelViewController);
    statePanel.identifier = _state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"];
    threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"]] = statePanel;
    statePanel.maximumThickness = 220;
    statePanel.minimumThickness = 220; // statePanel.collapsed = true;

    Object(_tabviewController__WEBPACK_IMPORTED_MODULE_13__["initTabView"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"]);
    Object(_tabviewController__WEBPACK_IMPORTED_MODULE_13__["addTabToSketchRightPanel"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"]);
    Object(_utils__WEBPACK_IMPORTED_MODULE_9__["setSettingForKey"])(_state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"], 'true');
    Object(_utils__WEBPACK_IMPORTED_MODULE_9__["setSettingForKey"])(_config__WEBPACK_IMPORTED_MODULE_10__["IS_SHOW_SKETCH"], 'true');
    runCommand(JSON.stringify({
      command: 'route',
      name: 'sketch'
    }));
  } catch (error) {
    console.log(error);
    var views = splitViewController.splitViewItems();

    for (var startPoint = 0; startPoint < views.length; startPoint++) {
      if (views[startPoint].identifier === _state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"] || views[startPoint].identifier === _state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"]) {
        splitViewController.removeSplitViewItem(views[startPoint]);
      }
    }

    onShutdown();
    Object(_utils_displayErrorMessage__WEBPACK_IMPORTED_MODULE_11__["default"])('Fin启动失败。请检查是否有相关类型插件正在使用中，为避免冲突，请前往管理插件，关闭相关插件，然后重试。');
  }
};

var onToggleSidePanel = function onToggleSidePanel(ctx) {
  console.info("\u2705 Dolphin\u4E3B\u9762\u677F\u542F\u52A8\u4E2D.... \u5F53\u524D Sketch \u7248\u672C ".concat(sketch_dom__WEBPACK_IMPORTED_MODULE_4__["version"].sketch, ", API \u7248\u672C ").concat(sketch_dom__WEBPACK_IMPORTED_MODULE_4__["version"].api));

  if (Number(sketch_dom__WEBPACK_IMPORTED_MODULE_4__["version"].sketch) < 70) {
    Object(_utils_displayErrorMessage__WEBPACK_IMPORTED_MODULE_11__["default"])('您的Sketch版本过低，请升级到 Sketch 70.0+ 以正常使用 Dolphin 插件。');
    return;
  } // 首次运行打点


  if (!Object(_utils__WEBPACK_IMPORTED_MODULE_9__["getSettingForKey"])('isActive')) {
    Object(_utils_apm__WEBPACK_IMPORTED_MODULE_6__["logActivePlugin"])(function () {
      Object(_utils__WEBPACK_IMPORTED_MODULE_9__["setSettingForKey"])('isActive', 'true');
    });
  }

  Object(_state__WEBPACK_IMPORTED_MODULE_8__["default"])(ctx);
  var threadDictionary = NSThread.mainThread().threadDictionary();

  if (threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"]]) {
    var splitViewController = _state__WEBPACK_IMPORTED_MODULE_8__["context"].document.splitViewController();
    Object(_utils__WEBPACK_IMPORTED_MODULE_9__["removeSettingForKey"])(_state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"]);
    Object(_utils__WEBPACK_IMPORTED_MODULE_9__["removeSettingForKey"])(_config__WEBPACK_IMPORTED_MODULE_10__["IS_SHOW_SKETCH"]);
    var views = splitViewController.splitViewItems();

    for (var startPoint = 0; startPoint < views.length; startPoint++) {
      if (views[startPoint].identifier === _state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"] || views[startPoint].identifier === _state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"]) {
        splitViewController.removeSplitViewItem(views[startPoint]);
      }
    }

    Object(_tabviewController__WEBPACK_IMPORTED_MODULE_13__["removeTabView"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"]);
    onShutdown();
    return;
  }

  Object(_utils__WEBPACK_IMPORTED_MODULE_9__["observerWindowResizeNotification"])(function () {});
  Object(_utils__WEBPACK_IMPORTED_MODULE_9__["observerFullScreenStatusChangedNotification"])(function () {
    Object(_tabviewController__WEBPACK_IMPORTED_MODULE_13__["refreshLayoutOfSplitView"])(_state__WEBPACK_IMPORTED_MODULE_8__["document"]);
  });
  insertSidePanel();
  setTimeout(function () {
    Object(_utils_injectcolorToken__WEBPACK_IMPORTED_MODULE_7__["default"])();
  }, 0);
};
var onCloseDocument = function onCloseDocument(ctx) {
  console.info('🪓 onCloseDocument hook invoked.');
  Object(_state__WEBPACK_IMPORTED_MODULE_8__["default"])(ctx);
  onShutdown();
}; // handler cleanly Long-running script

function onShutdown() {
  // eslint-disable-next-line no-console
  console.info('✅ Dolphin 关闭中...');
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var prefixRegExp = new RegExp("".concat(_state__WEBPACK_IMPORTED_MODULE_8__["IdentifierPrefix"], "*"));
  var webViewPrefixRegExp = new RegExp("".concat(_state__WEBPACK_IMPORTED_MODULE_8__["IdentifierPrefix"], "-webview*")); // clear MSClass

  for (var key in threadDictionary) {
    if (prefixRegExp.test(key)) {
      if (webViewPrefixRegExp.test(key)) {
        threadDictionary[key] && typeof threadDictionary[key].destory === 'function' && threadDictionary[key].destory();
      }

      threadDictionary.removeObjectForKey(key);
    }
  }

  console.log('✅ 开始清除内存数据...');
  [_state__WEBPACK_IMPORTED_MODULE_8__["toolBarIdentifier"], _state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"], _state__WEBPACK_IMPORTED_MODULE_8__["statePanelViewIdentifier"], _state__WEBPACK_IMPORTED_MODULE_8__["toolBarViewIdentifier"]].forEach(function (key) {
    return threadDictionary.removeObjectForKey(key);
  }); // clear WindowResizeNotification

  Object(_utils__WEBPACK_IMPORTED_MODULE_9__["removeObserverWindowResizeNotification"])();
  Object(_utils__WEBPACK_IMPORTED_MODULE_9__["removeObserverFullScreenStatusChangedNotification"])();
  fiber.cleanup();
} // 插件初始化加载

function onStartup() {
  console.info('✅ Dolphin 初始化中...');
}

var autoSidePanelCommand = function autoSidePanelCommand(ctx) {
  var isShow = Object(_utils__WEBPACK_IMPORTED_MODULE_9__["getSettingForKey"])(_config__WEBPACK_IMPORTED_MODULE_10__["IS_SHOW_SKETCH"]);

  if (isShow) {
    var toggleSidePanelCommand = ctx.command.pluginBundle().commands()['sketch-plugin-dolphin.toggle-side-panel'];
    ctx.command = toggleSidePanelCommand;
    AppController.sharedInstance().runPluginCommand_fromMenu_context(toggleSidePanelCommand, false, ctx);
  }
}; // export const onOpenDocument = (ctx) => {
//   console.info('🪓 onOpenDocument hook invoked.');
//   setTimeout(autoSidePanelCommand.bind(null, ctx), 100);
//   injectColorToken();
// };


var onSelectionChanged = function onSelectionChanged(ctx) {
  console.log('Start onSelectionChanged');
  Object(_state__WEBPACK_IMPORTED_MODULE_8__["default"])(ctx);
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var hasSelect = ctx.actionContext.newSelection.length !== 0;
  var hasOneElement = hasSelect && ctx.actionContext.newSelection.length === 1;
  var objectId = hasSelect ? ctx.actionContext.newSelection[0].objectID() : '';
  var params = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.documentSettingForKey(_state__WEBPACK_IMPORTED_MODULE_8__["document"], objectId);
  var statePanel = threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["statePanelIdentifier"]];
  var statePanelView = threadDictionary[_state__WEBPACK_IMPORTED_MODULE_8__["statePanelViewIdentifier"]];
  console.log('statePanelViewIdentifier', _state__WEBPACK_IMPORTED_MODULE_8__["statePanelViewIdentifier"]);
  var parsedParams = {};

  try {
    parsedParams = JSON.parse(params);
  } catch (error) {//
  }

  if (!hasSelect || !hasOneElement || !params || parsedParams.hidden) {
    if (statePanel) {
      hideStatePanel();
    }

    return;
  }

  if (statePanel && statePanelView) {
    showStatePanel();
    var lastObejctId = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.sessionVariable('@render/lastObjetcId');

    if (lastObejctId !== objectId) {
      statePanelView.webContents.executeJavaScript("receiveParams(".concat(JSON.stringify(params), ")"));
    }
  }

  console.log('Finish onSelectionChanged');
};
var onCopy = function onCopy() {
  console.log('Start onCopy.');
  var selectedDocument = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.getSelectedDocument();
  var selectedLayers = selectedDocument.selectedLayers;
  var layer = selectedLayers.layers[0];
  var params = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.documentSettingForKey(selectedDocument, layer.id);
  console.log(JSON.parse(params));

  if (layer) {
    sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setGlobalSettingForKey('@Copy/OriginParams', params);
    sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setGlobalSettingForKey('@Copy/CopyingFlag', 'true');
  }

  console.log('Finish onCopy.');
};
var onPaste = function onPaste() {
  console.log('Start onPaste.');
  var params = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.globalSettingForKey('@Copy/OriginParams');
  var copyingFlag = sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.globalSettingForKey('@Copy/CopyingFlag');

  if (copyingFlag === 'true') {
    var selectedDocument = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.getSelectedDocument();
    var selectedLayers = selectedDocument.selectedLayers;
    var layer = selectedLayers.layers[0];

    if (params && layer) {
      params = JSON.parse(params);
      var objectId = layer.id;
      sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setDocumentSettingForKey(selectedDocument, layer.id, JSON.stringify(_objectSpread(_objectSpread({}, params), {}, {
        objectId: objectId
      })));
    }
  }

  sketch_settings__WEBPACK_IMPORTED_MODULE_3___default.a.setGlobalSettingForKey('@Copy/CopyingFlag', null);
  console.log('Finish onPaste.');
};
var onlyMutil = true;
var onlyNotPingFang = true;
var fixSingleLineLineHeight = function fixSingleLineLineHeight() {
  sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message('111');
  var selectedDocument = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.getSelectedDocument();
  var selectedLayers = selectedDocument.selectedLayers;

  if (selectedLayers.length) {
    selectedLayers.forEach(function (layer) {
      fixLineHeight(layer, false);
    });

    if (onlyMutil) {
      sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message('🎈多行行高默认不修复！');
    } else if (onlyNotPingFang) {
      sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message('🎈非苹方字体不修复！');
    } else {
      sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message("\uD83C\uDF89 \u5355\u884C\u884C\u9AD8\u4FEE\u590D\u6210\u529F\uFF01");
    }
  } else {
    sketch_ui__WEBPACK_IMPORTED_MODULE_2___default.a.message('请选择一个图层！');
  }
}; // 处理编组第二位字体偏移

var countTextInGroup = 0;
var firstTextOffset = 0;

function fixLineHeight(layer) {
  var multi = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var map = {
    8: {
      lineHeight: 11,
      start: 6
    },
    // 10
    9: {
      lineHeight: 13,
      start: 7
    },
    // 11
    10: {
      lineHeight: 14,
      start: 8
    },
    // 12
    11: {
      lineHeight: 16,
      start: 8
    },
    // 13
    12: {
      lineHeight: 17,
      start: 9
    },
    // 14
    13: {
      lineHeight: 18,
      start: 10
    },
    // 16
    14: {
      lineHeight: 20,
      start: 11
    },
    // 17
    15: {
      lineHeight: 21,
      start: 11
    },
    // 18
    16: {
      lineHeight: 22,
      start: 12
    },
    // 19
    17: {
      lineHeight: 24,
      start: 13
    },
    // 20
    18: {
      lineHeight: 25,
      start: 13
    },
    // 21
    19: {
      lineHeight: 26,
      start: 14
    },
    // 23
    20: {
      lineHeight: 28,
      start: 15
    },
    // 24
    21: {
      lineHeight: 29,
      start: 16
    },
    // 25
    22: {
      lineHeight: 30,
      start: 16
    },
    // 26
    23: {
      lineHeight: 32,
      start: 17
    },
    // 27
    24: {
      lineHeight: 33,
      start: 18
    },
    // 29
    25: {
      lineHeight: 36,
      start: 19
    } // 30

  };

  if (layer.type === 'Text') {
    countTextInGroup++;
    layer.sketchObject.syncTextStyleAttributes();
    var fontSize = layer.style.fontSize;
    var preLineHeight = layer.style.lineHeight || map[fontSize].lineHeight;
    var offset = 0;
    var preOffset = 0;
    var nowOffset = 0;
    var lineHeight = Math.round(fontSize * 1.193359);
    var part1 = map[fontSize].start;
    preOffset = preLineHeight <= part1 ? preLineHeight : part1 + Math.floor((preLineHeight - map[fontSize].start) / 2);
    nowOffset = lineHeight <= part1 ? lineHeight : part1 + Math.floor((lineHeight - map[fontSize].start) / 2);
    offset = preOffset - nowOffset;
    var y = layer.frame.y;

    if (countTextInGroup === 1) {
      firstTextOffset = offset;
    }

    if (countTextInGroup === 2) {
      offset -= firstTextOffset;
    }

    if (fontSize > 25 || fontSize < 8 || fontSize % 1 !== 0) {
      return;
    }

    if (layer.frame.height >= fontSize * 2) {
      return;
    }

    onlyMutil = false;

    if (layer.style.fontFamily !== 'PingFang SC') {
      return;
    }

    onlyNotPingFang = false;
    layer.style.lineHeight = lineHeight;
    layer.frame.y = y + offset;
  }

  if (layer.layers) {
    countTextInGroup = 0;
    layer.layers.forEach(function (subLayer) {
      return fixLineHeight(subLayer, multi);
    });
  }
}

/***/ }),

/***/ "./src/state.js":
/*!**********************!*\
  !*** ./src/state.js ***!
  \**********************/
/*! exports provided: context, document, version, sketchVersion, pluginFolderPath, resourcesPath, documentObjectID, IdentifierPrefix, toolBarIdentifier, toolBarViewIdentifier, statePanelIdentifier, statePanelViewIdentifier, WINDOW_MOVE_INSTANCE, WINDOW_MOVE_SELECTOR, WINDOW_FULL_SCREEN_SELECTOR, WINDOW_FULL_SCREEN_INSTANCE, Menus, pageId, SavePageId, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "context", function() { return context; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "document", function() { return document; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "version", function() { return version; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sketchVersion", function() { return sketchVersion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pluginFolderPath", function() { return pluginFolderPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resourcesPath", function() { return resourcesPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentObjectID", function() { return documentObjectID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IdentifierPrefix", function() { return IdentifierPrefix; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toolBarIdentifier", function() { return toolBarIdentifier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toolBarViewIdentifier", function() { return toolBarViewIdentifier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "statePanelIdentifier", function() { return statePanelIdentifier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "statePanelViewIdentifier", function() { return statePanelViewIdentifier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WINDOW_MOVE_INSTANCE", function() { return WINDOW_MOVE_INSTANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WINDOW_MOVE_SELECTOR", function() { return WINDOW_MOVE_SELECTOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WINDOW_FULL_SCREEN_SELECTOR", function() { return WINDOW_FULL_SCREEN_SELECTOR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WINDOW_FULL_SCREEN_INSTANCE", function() { return WINDOW_FULL_SCREEN_INSTANCE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Menus", function() { return Menus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pageId", function() { return pageId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavePageId", function() { return SavePageId; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config.js */ "./src/config.js");


var context;
var document;
var version;
var sketchVersion;
var pluginFolderPath;
var resourcesPath;
var documentObjectID;
var IdentifierPrefix;
var toolBarIdentifier;
var toolBarViewIdentifier;
var statePanelIdentifier;
var statePanelViewIdentifier;
var WINDOW_MOVE_INSTANCE;
var WINDOW_MOVE_SELECTOR;
var WINDOW_FULL_SCREEN_SELECTOR;
var WINDOW_FULL_SCREEN_INSTANCE;
var Menus;
var pageId;
var SavePageId = function SavePageId(id) {
  pageId = id;
};

function updateIdentifier(objectID) {
  IdentifierPrefix = objectID ? "sketch-plugin-dolphin-".concat(objectID) : 'sketch-plugin-dolphin';
  toolBarIdentifier = "".concat(IdentifierPrefix, "-toolbar");
  toolBarViewIdentifier = "".concat(IdentifierPrefix, "-webview-toolbar-view");
  statePanelIdentifier = "".concat(IdentifierPrefix, "-state-panel");
  statePanelViewIdentifier = "".concat(IdentifierPrefix, "-webview-state-panel-view");
  WINDOW_MOVE_INSTANCE = "window-move-instance-".concat(objectID);
  WINDOW_MOVE_SELECTOR = "window-move-selector-".concat(objectID);
  WINDOW_FULL_SCREEN_SELECTOR = "window-full-screen-selector-".concat(objectID);
  WINDOW_FULL_SCREEN_INSTANCE = "window-full-screen-instance-".concat(objectID);
  Menus = [{
    rect: NSMakeRect(0, 0, 48, 48),
    size: NSMakeSize(48, 48),
    icon: 'icon-sketch',
    activeIcon: 'icon-sketch-active',
    tooltip: 'sketch',
    identifier: "".concat(IdentifierPrefix, "-sketch"),
    name: 'sketch',
    type: 2,
    inGravityType: 1
  }, {
    rect: NSMakeRect(0, 0, 48, 48),
    size: NSMakeSize(48, 48),
    icon: 'icon-control',
    activeIcon: 'icon-control-active',
    tooltip: '控件',
    identifier: "".concat(IdentifierPrefix, "-menu"),
    type: 2,
    name: 'control',
    inGravityType: 1,
    url: "".concat(_config_js__WEBPACK_IMPORTED_MODULE_1__["prefix"], "/components/control")
  }, {
    rect: NSMakeRect(0, 0, 48, 48),
    size: NSMakeSize(48, 48),
    icon: 'icon-component',
    activeIcon: 'icon-component-active',
    tooltip: '组件',
    identifier: "".concat(IdentifierPrefix, "-menu"),
    name: 'main-component',
    type: 2,
    inGravityType: 1,
    url: "".concat(_config_js__WEBPACK_IMPORTED_MODULE_1__["prefix"], "/components/main-component")
  }, {
    rect: NSMakeRect(0, 0, 48, 48),
    size: NSMakeSize(48, 48),
    icon: 'icon-template',
    activeIcon: 'icon-template-active',
    tooltip: '模板',
    identifier: "".concat(IdentifierPrefix, "-menu"),
    name: 'template',
    type: 2,
    inGravityType: 1,
    url: "".concat(_config_js__WEBPACK_IMPORTED_MODULE_1__["prefix"], "/no-page")
  }, {
    rect: NSMakeRect(0, 0, 48, 48),
    size: NSMakeSize(48, 48),
    icon: 'icon-material',
    activeIcon: 'icon-material-active',
    tooltip: '素材',
    identifier: "".concat(IdentifierPrefix, "-menu"),
    name: 'material',
    type: 2,
    inGravityType: 1,
    url: "".concat(_config_js__WEBPACK_IMPORTED_MODULE_1__["prefix"], "/no-page")
  }, {
    rect: NSMakeRect(0, 0, 48, 48),
    size: NSMakeSize(48, 48),
    icon: 'icon-qa',
    activeIcon: 'icon-qa',
    tooltip: '帮助',
    identifier: "".concat(IdentifierPrefix, "-menu"),
    type: 2,
    inGravityType: 3,
    url: "".concat(_config_js__WEBPACK_IMPORTED_MODULE_1__["prefix"], "/no-page")
  } // {
  //   rect: NSMakeRect(0, 0, 48, 48),
  //   size: NSMakeSize(24, 24),
  //   icon: 'setting',
  //   activeIcon: 'setting-active',
  //   tooltip: '设置',
  //   identifier: `${IdentifierPrefix}-menu.setting`,
  //   wkIdentifier: `${IdentifierPrefix}-webview.setting`,
  //   type: 2,
  //   inGravityType: 3,
  //   url: 'https://aotu.io/',
  // }
  ];
}

function getPluginFolderPath(ctx) {
  // Get absolute folder path of plugin
  var split = ctx.scriptPath.split('/');
  split.splice(-3, 3);
  return split.join('/');
}

/* harmony default export */ __webpack_exports__["default"] = (function (ctx) {
  context = ctx;
  document = context.document || context.actionContext.document || MSDocument.currentDocument();
  documentObjectID = document.documentData().objectID();
  updateIdentifier(documentObjectID); // eslint-disable-next-line no-new-wrappers

  version = new String(context.plugin.version()).toString(); // Sketch 66 已移除 context.api()  Javascript API (v1.0)
  // sketchVersion = new String(context.api().version).toString()
  // eslint-disable-next-line no-new-wrappers

  sketchVersion = new String(sketch__WEBPACK_IMPORTED_MODULE_0___default.a.version.sketch).toString();
  pluginFolderPath = getPluginFolderPath(context);
  resourcesPath = "".concat(pluginFolderPath, "/Contents/Resources");
});

/***/ }),

/***/ "./src/tabviewController.js":
/*!**********************************!*\
  !*** ./src/tabviewController.js ***!
  \**********************************/
/*! exports provided: initTabView, addTabToSketchRightPanel, hasTabView, resetSketchRightPanelToDefault, removeTabView, selectTabItemByIndex, selectTabItemById, addWebViewToTab, removeTabItemByIndex, removeTabItemById, getTabItemById, getTabItemIndexById, currentTabItem, refreshLayoutOfSplitView, getTabView */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initTabView", function() { return initTabView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addTabToSketchRightPanel", function() { return addTabToSketchRightPanel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hasTabView", function() { return hasTabView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetSketchRightPanelToDefault", function() { return resetSketchRightPanelToDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeTabView", function() { return removeTabView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectTabItemByIndex", function() { return selectTabItemByIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectTabItemById", function() { return selectTabItemById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addWebViewToTab", function() { return addWebViewToTab; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeTabItemByIndex", function() { return removeTabItemByIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeTabItemById", function() { return removeTabItemById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabItemById", function() { return getTabItemById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabItemIndexById", function() { return getTabItemIndexById; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "currentTabItem", function() { return currentTabItem; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "refreshLayoutOfSplitView", function() { return refreshLayoutOfSplitView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTabView", function() { return getTabView; });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./utils */ "./src/utils/index.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config */ "./src/config.js");
/* eslint-disable prefer-destructuring */

/* eslint-disable dot-notation */


var threadDictionary = NSThread.mainThread().threadDictionary();
var globalTabView = null;
var tabViewConstrains = null;
var contentContainerConstrains = null;
var initTabView = function initTabView(document) {
  console.info('Start to execute initTabView');
  var sketchStackViewFromInspector = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["getSketchStackViewFromInspector"])(document);
  var contentContainerViewFromInspector = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["getContentContainerViewFromInspector"])(document);
  globalTabView = NSTabView.alloc().initWithFrame(CGRectMake(0, 0, 0, 0));
  globalTabView.tabViewType = NSNoTabsNoBorder;
  var width = sketchStackViewFromInspector.frame().size.width;
  var tabViewWidthConstrain = globalTabView.widthAnchor().constraintEqualToConstant(width);
  var tabViewMinWidthConstrain = globalTabView.widthAnchor().constraintGreaterThanOrEqualToConstant(_config__WEBPACK_IMPORTED_MODULE_1__["minWidth"]);
  var tabViewMinHeightConstrain = globalTabView.heightAnchor().constraintGreaterThanOrEqualToConstant(_config__WEBPACK_IMPORTED_MODULE_1__["minHeight"]);
  var l = contentContainerViewFromInspector.widthAnchor().constraintEqualToConstant(width);
  tabViewConstrains = NSArray.arrayWithArray([tabViewMinWidthConstrain, tabViewMinHeightConstrain, l]);
  contentContainerConstrains = NSArray.arrayWithArray([tabViewWidthConstrain]);
  console.info('Finish to execute initTabView');
  threadDictionary['sketchStackViewFromInspector'] = sketchStackViewFromInspector;
  threadDictionary['contentContainerViewFromInspector'] = contentContainerViewFromInspector;
  threadDictionary['tabViewConstrains'] = tabViewConstrains;
  threadDictionary['contentContainerConstrains'] = contentContainerConstrains;
  threadDictionary['globalTabView'] = globalTabView;
  return globalTabView;
};
var addTabToSketchRightPanel = function addTabToSketchRightPanel() {
  var sketchStackViewFromInspector = threadDictionary['sketchStackViewFromInspector'];
  var contentContainerViewFromInspector = threadDictionary['contentContainerViewFromInspector'];
  var contentContainerViewFromInspectorIndex;
  console.info('Start to execute addTabToSketchRightPanel');
  NSLayoutConstraint.deactivateConstraints(tabViewConstrains);
  NSLayoutConstraint.activateConstraints(contentContainerConstrains);

  try {
    contentContainerViewFromInspectorIndex = sketchStackViewFromInspector.arrangedSubviews().indexOfObject(contentContainerViewFromInspector);
  } catch (e) {
    console.error(e);
  }

  contentContainerViewFromInspector.removeFromSuperview();
  console.info('Start to execute addSketchInspectorToTab');
  var tabViewItem = NSTabViewItem.alloc().initWithIdentifier(_config__WEBPACK_IMPORTED_MODULE_1__["SKETCH_INSPECTOR"]);
  tabViewItem.view = contentContainerViewFromInspector;
  getTabView().insertTabViewItem_atIndex(tabViewItem, 0);
  console.info('Finish to execute addSketchInspectorToTab');
  sketchStackViewFromInspector.insertArrangedSubview_atIndex(getTabView(), contentContainerViewFromInspectorIndex);
  console.info('Finish to execute addTabToSketchRightPanel');
};
var hasTabView = function hasTabView() {
  var sketchStackViewFromInspector = threadDictionary['sketchStackViewFromInspector'];
  return !sketchStackViewFromInspector.arrangedSubviews().containsObject(getTabView());
};
var resetSketchRightPanelToDefault = function resetSketchRightPanelToDefault(document) {
  console.info('Start to execute resetSketchRightPanelToDefault');
  NSLayoutConstraint.deactivateConstraints(threadDictionary['contentContainerConstrains']);
  NSLayoutConstraint.activateConstraints(threadDictionary['tabViewConstrains']);
  var sketchStackViewFromInspector = threadDictionary['sketchStackViewFromInspector'];
  var contentContainerViewFromInspector = threadDictionary['contentContainerViewFromInspector'];
  var globalTabViewIndex = sketchStackViewFromInspector.arrangedSubviews().indexOfObject(getTabView());
  contentContainerViewFromInspector.removeFromSuperview();
  getTabView().removeFromSuperview();
  sketchStackViewFromInspector.insertArrangedSubview_atIndex(contentContainerViewFromInspector, globalTabViewIndex);
  refreshLayoutOfSplitView(document);
  console.info('Finish to execute resetSketchRightPanelToDefault');
};
var removeTabView = function removeTabView(document) {
  var sketchStackViewFromInspector = threadDictionary['sketchStackViewFromInspector'];
  var contentContainerViewFromInspector = threadDictionary['contentContainerViewFromInspector'];
  console.info('Start to removeTabView');

  if (contentContainerViewFromInspector && sketchStackViewFromInspector && getTabView()) {
    var tabViewItems = getTabView().tabViewItems();

    for (var index = 0; index < tabViewItems.count(); index += 1) {
      var current = tabViewItems.objectAtIndex(index);
      getTabView().removeTabViewItem(current);
    }

    resetSketchRightPanelToDefault(document);
  } else {
    console.error('RemoveTabView failed, one of the following view is null, '.concat(contentContainerViewFromInspector, ', ').concat(sketchStackViewFromInspector, ', ').concat(getTabView()));
  }

  console.info('Finish removeTabView');
};
var selectTabItemByIndex = function selectTabItemByIndex(index) {
  getTabView().selectTabViewItemAtIndex(index);
};
var selectTabItemById = function selectTabItemById(id) {
  var index = getTabView().indexOfTabViewItemWithIdentifier(id);
  selectTabItemByIndex(index);
};
var addWebViewToTab = function addWebViewToTab(browserWindow) {
  console.info('Start to addWebViewToTab');
  var tabViewItem = NSTabViewItem.alloc().initWithIdentifier(browserWindow.id);
  tabViewItem.view = browserWindow._webview;
  getTabView().insertTabViewItem_atIndex(tabViewItem, getTabView().numberOfTabViewItems());
  console.info('Finish addWebViewToTab');
};
var removeTabItemByIndex = function removeTabItemByIndex(index) {
  var tabViewItem = getTabView().tabViewItemAtIndex(index);
  getTabView().removeTabViewItem(tabViewItem);
};
var removeTabItemById = function removeTabItemById(id) {
  var index = getTabView().indexOfTabViewItemWithIdentifier(id);
  removeTabItemByIndex(index);
};
var getTabItemById = function getTabItemById(id) {
  var index = getTabView().indexOfTabViewItemWithIdentifier(id);
  return getTabView().tabViewItemAtIndex(index);
};
var getTabItemIndexById = function getTabItemIndexById(id) {
  return getTabView().indexOfTabViewItemWithIdentifier(id);
};
var currentTabItem = function currentTabItem() {
  var tabView = getTabView();
  var currentTabViewItem = tabView.selectedTabViewItem();
  return {
    index: tabView.indexOfTabViewItem(currentTabViewItem),
    identifier: tabView.identifier()
  };
};
var refreshLayoutOfSplitView = function refreshLayoutOfSplitView(document) {
  console.info('Start to refreshLayoutOfSplitView');
  var splitViewController = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["getSplitViewController"])(document);
  var splitViewItemIndexForSketchInspector = Object(_utils__WEBPACK_IMPORTED_MODULE_0__["getSplitViewItemIndexForSketchInspector"])(document);
  splitViewController.splitViewItems()[splitViewItemIndexForSketchInspector].collapsed = true;
  splitViewController.splitViewItems()[splitViewItemIndexForSketchInspector].collapsed = false;
  splitViewController.splitViewItems()[splitViewItemIndexForSketchInspector - 1].collapsed = true;
  splitViewController.splitViewItems()[splitViewItemIndexForSketchInspector - 1].collapsed = false;
  splitViewController.splitViewItems()[splitViewItemIndexForSketchInspector - 2].collapsed = true;
  splitViewController.splitViewItems()[splitViewItemIndexForSketchInspector - 2].collapsed = false;
  console.info('Finish to refreshLayoutOfSplitView');
};
var getTabView = function getTabView() {
  return threadDictionary['globalTabView'];
};

/***/ }),

/***/ "./src/utils/apm.js":
/*!**************************!*\
  !*** ./src/utils/apm.js ***!
  \**************************/
/*! exports provided: logActivePlugin, logDailyUseage, logTotalUsage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "logActivePlugin", function() { return logActivePlugin; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "logDailyUseage", function() { return logDailyUseage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "logTotalUsage", function() { return logTotalUsage; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);


var APM_TEST = 'https://qa-wapm.igame.163.com/';
var APM_ONLINE = 'https://sentry.music.163.com/wapm/';
var COLLECT_API = 'api/sdk/collectEvent';

function fetchWithTimeout(url, options) {
  var timeout = options.timeout;

  if (timeout) {
    return Promise.race([fetch(url, options), new Promise(function (resolve, reject) {
      setTimeout(reject, timeout);
    })]);
  } else {
    return fetch(url, options);
  }
}

var MusicAPM = /*#__PURE__*/function () {
  function MusicAPM() {
    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, MusicAPM);
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(MusicAPM, [{
    key: "install",
    value:
    /**
     * @param {string} appKey 应用唯一key。
     * @param {Object} options 应用配置。
     * @param {boolean} [options.isTest] 是否为测试环境, 默认false。
     * @param {number} [options.timeout] 请求超时时间，单位ms, 默认2000。
     * @param {number} [options.maxReqQueueCount] 请求队列最大值，当队列满时不接受新请求, 默认100。
     */
    function install(appKey, options) {
      if (this.installed) {
        return this;
      }

      if (!appKey) {
        console.warn('MusicAPM install fail: absence of appKey');
        return;
      }

      this.appKey = appKey;
      var isTest = options.isTest,
          timeout = options.timeout,
          maxReqQueueCount = options.maxReqQueueCount;
      this.api = "".concat(isTest ? APM_TEST : APM_ONLINE).concat(COLLECT_API);
      this.timeout = timeout || 2000;
      this.maxReqQueueCount = maxReqQueueCount || 100;
      this.installed = true;
      return this;
    }
  }, {
    key: "uninstall",
    value: function uninstall() {
      if (!this.installed) return this;
      this.installed = false;
      return this;
    }
    /**
     * @deprecated 请使用 uploadEvent 替代该方法
     * @see uploadEvent
     * @param {string} eventName 事件名。
     * @param {Object} [attribute=] 事件属性
     * @param {function} [cb=] 注册回调事件
     */

  }, {
    key: "traceEvent",
    value: function traceEvent(name, attributes, cb) {
      if (!this.installed) {
        console.warn('MusicAPM has not been installed, therefore no event will be sent. call MusicAPM.install() to fix this.');
        return;
      }

      console.warn('MusicAPM::traceEvent is depressed, please use uploadEvent instead');

      this._sendRequest(this.api, {
        appKey: this.appKey,
        events: [{
          name: name,
          attributes: attributes
        }]
      }, cb);
    }
    /**
     * @param {object} event 事件对象
     * @param {string} event.name  事件名
     * @param {object} [event.attributes] 事件属性
     * @param {number} [event.value] 事件值
     * @param {function} [cb=] 注册回调事件
     */

  }, {
    key: "uploadEvent",
    value: function uploadEvent(event, cb) {
      if (!this.installed) {
        console.warn('MusicAPM has not been installed, therefore no event will be sent. call MusicAPM.install() to fix this.');
        return;
      }

      var name = event.name,
          attributes = event.attributes,
          value = event.value;

      if (!name) {
        console.warn('MusicAPM::uploadEvent fail: absence of event.name');
        return;
      }

      this._sendRequest(this.api, {
        appKey: this.appKey,
        events: [{
          name: name,
          attributes: attributes,
          value: value
        }]
      }, cb);
    }
    /**
     * @private
     */

  }, {
    key: "_sendRequest",
    value: function _sendRequest(api, body, cb) {
      var options = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': "".concat(JSON.stringify(body).length)
        },
        body: JSON.stringify(body),
        timeout: this.timeout
      };
      fetchWithTimeout(api, options).then(function () {
        cb && cb(null);
      });
    }
  }]);

  return MusicAPM;
}();

var globalAmp = new MusicAPM();
globalAmp.install('cae5d208-37cd-4455-926f-f9f2fdbd0e76', {
  timeout: 5000
});
function logActivePlugin(cb) {
  globalAmp.uploadEvent({
    name: 'dolphin-plugin-registry'
  }, function () {
    cb && cb();
    console.log('插件激活打点....');
  });
}
function logDailyUseage(cb) {
  globalAmp.uploadEvent({
    name: 'dolphin-plugin-usage'
  }, function () {
    cb && cb();
    console.log('插件UV打点....');
  });
}
function logTotalUsage(userId, cb) {
  globalAmp.uploadEvent({
    name: 'dolphin-plugin-total-usage',
    attributes: {}
  }, function () {
    cb && cb();
    console.log('插件使用次数....');
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/utils/displayErrorMessage.js":
/*!******************************************!*\
  !*** ./src/utils/displayErrorMessage.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/typeof */ "./node_modules/@babel/runtime/helpers/typeof.js");
/* harmony import */ var _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/ui */ "sketch/ui");
/* harmony import */ var sketch_ui__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_ui__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ __webpack_exports__["default"] = (function (args) {
  sketch_ui__WEBPACK_IMPORTED_MODULE_1___default.a.alert('提示', _babel_runtime_helpers_typeof__WEBPACK_IMPORTED_MODULE_0___default()(args) === 'object' ? args.toString() : args);
});

/***/ }),

/***/ "./src/utils/element.js":
/*!******************************!*\
  !*** ./src/utils/element.js ***!
  \******************************/
/*! exports provided: getImageURL, createImage, createImageView, createBoxSeparator, addButton, createBounds, createPanel, createView, createBox, createTextField */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getImageURL", function() { return getImageURL; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createImage", function() { return createImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createImageView", function() { return createImageView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createBoxSeparator", function() { return createBoxSeparator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addButton", function() { return addButton; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createBounds", function() { return createBounds; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createPanel", function() { return createPanel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createView", function() { return createView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createBox", function() { return createBox; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createTextField", function() { return createTextField; });
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../state */ "./src/state.js");

/**
 * getImageURL 获取 icon 路径
 * @param {*} name
 */

var getImageURL = function getImageURL(name) {
  var isRetinaDisplay = NSScreen.mainScreen().backingScaleFactor() > 1; // const suffix = isRetinaDisplay ? '@2x' : ''

  var suffix = '';
  var pluginSketch = _state__WEBPACK_IMPORTED_MODULE_0__["context"].plugin.url();
  var imageURL = pluginSketch.URLByAppendingPathComponent('Contents').URLByAppendingPathComponent('Resources').URLByAppendingPathComponent('icons').URLByAppendingPathComponent("".concat(name + suffix, ".png"));
  return imageURL;
};
/**
 * createImage 创建 NSImage
 * @param {*} imageURL
 * @param {*} size
 */

var createImage = function createImage(imageURL, size) {
  // NSImage.alloc().initWithSize([width, height])
  var Image = NSImage.alloc().initWithContentsOfURL(imageURL);
  size && Image.setSize(size);
  Image.setScalesWhenResized(true);
  return Image;
};
/**
 * createImageView 创建 NSImageView
 * @param {*} rect
 * @param {*} icon
 * @param {*} size
 */

var createImageView = function createImageView(rect, icon, size) {
  var imageView = NSImageView.alloc().initWithFrame(rect);
  var imageURL = getImageURL(icon);
  var image = createImage(imageURL, size);
  imageView.setImage(image);
  imageView.setAutoresizingMask(5);
  return imageView;
};
/**
 * createImageView 创建 NSBoxSeparator
 */

var createBoxSeparator = function createBoxSeparator() {
  // set to 0 in width and height
  var separtorBox = NSBox.alloc().initWithFrame(NSZeroRect); // Specifies that the box is a separator

  separtorBox.setBoxType(2 || false);
  separtorBox.setBorderColor(NSColor.colorWithHex('#F5F5F5'));

  try {
    separtorBox.setBorderColor(NSColor.colorWithSRGBRed_green_blue_alpha(1.0, 1.0, 1.0, 1.0));
  } catch (error) {
    console.error(error);
  } // separtorBox.setTransparent(true)


  return separtorBox;
};
/**
 * addButton 创建 NSButton
 * @param {*} param { rect, size, icon, activeIcon, tooltip = '', type = 5, callAction }
 */

var addButton = function addButton(_ref) {
  var rect = _ref.rect,
      size = _ref.size,
      icon = _ref.icon,
      activeIcon = _ref.activeIcon,
      _ref$tooltip = _ref.tooltip,
      tooltip = _ref$tooltip === void 0 ? '' : _ref$tooltip,
      _ref$type = _ref.type,
      type = _ref$type === void 0 ? 5 : _ref$type,
      callAction = _ref.callAction;
  var button = rect ? NSButton.alloc().initWithFrame(rect) : NSButton.alloc().init();
  var imageURL = getImageURL(icon);
  var image = createImage(imageURL, size);
  button.setImage(image);

  if (activeIcon) {
    var activeImageURL = getImageURL(activeIcon);
    var activeImage = createImage(activeImageURL, size);
    button.setAlternateImage(activeImage);
  } else {
    button.setAlternateImage(image);
  } // button.layer().setBackgroundColor(CGColorCreateGenericRGB(204/255,204/255,204/255,1.0));


  button.setBordered(false);
  button.showsBorderOnlyWhileMouseInside();
  button.sizeToFit();
  button.setToolTip(tooltip);
  button.setButtonType(type || NSMomentaryChangeButton);
  button.setCOSJSTargetFunction(callAction);
  button.setAction('callAction:');

  button.removeBadge = function () {
    button.setImage(image);
    button.hasBadge = false;
  };

  button.icon = icon;
  return button;
};
/**
 * 创建 bounds
 * @param {*} x
 * @param {*} y
 * @param {*} width
 * @param {*} height
 */

var createBounds = function createBounds() {
  var x = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  var y = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  var width = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
  var height = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
  return NSMakeRect(x, y, width, height);
};
/**
 * createView 创建 NSPanel
 * @param {*} frame  options
 */

var createPanel = function createPanel() {
  var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
    width: 800,
    height: 600,
    minWidth: 0,
    minHeight: 0,
    x: 0,
    y: 0,
    title: 'panel',
    identifier: 'sketch-panel',
    vibrancy: true
  };
  COScript.currentCOScript().setShouldKeepAround(true);
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var mainScreenRect = NSScreen.screens().firstObject().frame();
  var Bounds = NSMakeRect(options.x ? options.x : Math.round((NSWidth(mainScreenRect) - options.width) / 2), options.y ? NSHeight(mainScreenRect) - options.y : Math.round((NSHeight(mainScreenRect) - options.height) / 2), options.width, options.height);
  var panel = NSPanel.alloc().init();
  panel.setFrame_display(Bounds, true);
  panel.setOpaque(0);
  threadDictionary[options.identifier] = panel; // NSWindowStyleMaskDocModalWindow 直角

  panel.setStyleMask(NSWindowStyleMaskFullSizeContentView | NSBorderlessWindowMask | NSResizableWindowMask | NSTexturedBackgroundWindowMask | NSTitledWindowMask | NSClosableWindowMask | NSFullSizeContentViewWindowMask | NSWindowStyleMaskResizable);
  panel.setBackgroundColor(NSColor.whiteColor() || NSColor.windowBackgroundColor());
  panel.title = options.title;
  panel.movableByWindowBackground = true;
  panel.titlebarAppearsTransparent = true;
  panel.titleVisibility = NSWindowTitleHidden;
  panel.center();
  panel.makeKeyAndOrderFront(null);
  panel.setLevel(NSFloatingWindowLevel);
  panel.minSize = NSMakeSize(options.minWidth, options.minHeight);
  panel.standardWindowButton(NSWindowZoomButton).setHidden(true);
  panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true);
  panel.standardWindowButton(NSWindowCloseButton).setHidden(true); // Some third-party macOS utilities check the zoom button's enabled state to
  // determine whether to show custom UI on hover, so we disable it here to
  // prevent them from doing so in a frameless app window.

  panel.standardWindowButton(NSWindowZoomButton).setEnabled(false); // The fullscreen button should always be hidden for frameless window.

  if (panel.standardWindowButton(NSWindowFullScreenButton)) {
    panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true);
  }

  panel.showsToolbarButton = false;
  panel.movableByWindowBackground = true;

  if (options.vibrancy) {
    // Create the blurred background
    var effectView = NSVisualEffectView.alloc().initWithFrame(NSMakeRect(0, 0, options.width, options.height));
    effectView.setMaterial(NSVisualEffectMaterialPopover);
    effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable);
    effectView.setAppearance(NSAppearance.appearanceNamed(NSAppearanceNameVibrantLight));
    effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow); // Add it to the panel

    panel.contentView().addSubview(effectView);
  }

  var closeButton = panel.standardWindowButton(NSWindowCloseButton);
  closeButton.setCOSJSTargetFunction(function (sender) {
    log(sender);
    panel.close(); // Remove the reference to the panel

    threadDictionary.removeObjectForKey(options.identifier); // Stop this Long-running script

    COScript.currentCOScript().setShouldKeepAround(false);
  });
  return panel;
};
/**
 * createView 创建 NSView
 * @param {*} frame  NSMakeRect(0, 0, 40, 40)
 */

var createView = function createView(frame) {
  var view = NSView.alloc().initWithFrame(frame);
  view.setFlipped(1);
  return view;
};
/**
 * createBox 创建 NSBox
 * @param {*} frame  NSMakeRect(0, 0, 40, 40)
 */

var createBox = function createBox(frame) {
  var box = NSBox.alloc().initWithFrame(frame);
  box.setTitle('');
  return box;
};
/**
 * createBox 创建 createTextField
 * @param {*} string
 * @param {*} frame NSMakeRect(0, 0, 40, 40)
 */

var createTextField = function createTextField(string, frame) {
  var field = NSTextField.alloc().initWithFrame(frame);
  field.setStringValue(string);
  field.setFont(NSFont.systemFontOfSize(12));
  field.setTextColor(NSColor.colorWithCalibratedRed_green_blue_alpha(0, 0, 0, 0.7));
  field.setBezeled(0);
  field.setBackgroundColor(NSColor.windowBackgroundColor());
  field.setEditable(0);
  return field;
};

/***/ }),

/***/ "./src/utils/file.js":
/*!***************************!*\
  !*** ./src/utils/file.js ***!
  \***************************/
/*! exports provided: File */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "File", function() { return File; });
/**
 * File 文件操作
 * NSString.stringWithFormat('%@', content)
 */
var File = {
  fileManager: NSFileManager.defaultManager(),
  _stringify: function _stringify(jsonData, opt) {
    opt = opt ? 1 : 0;
    var nsJson = NSJSONSerialization.dataWithJSONObject_options_error_(jsonData, opt, nil);
    return NSString.alloc().initWithData_encoding(nsJson, 4);
  },
  writeFile: function writeFile(content, path) {
    content = NSString.stringWithFormat('%@', content);
    path = NSString.stringWithFormat('%@', path);
    return content.writeToFile_atomically_encoding_error_(path, !0, 4, nil);
  },
  copyFile: function copyFile(path, dist) {
    return this.fileManager.fileExistsAtPath(path) ? this.fileManager.copyItemAtPath_toPath_error(path, dist, nil) : nil;
  },
  mkDir: function mkDir(path) {
    return !this.fileManager.fileExistsAtPath(path) && this.fileManager.createDirectoryAtPath_withIntermediateDirectories_attributes_error_(path, !0, nil, nil);
  },
  readJSON: function readJSON(path, opt) {
    var src = NSData.dataWithContentsOfFile(path);
    var options = !0 === opt ? 1 : 0;
    return NSJSONSerialization.JSONObjectWithData_options_error(src, options, nil);
  },
  size: function size(patch) {
    var size = 0;

    try {
      size = this.fileManager.attributesOfItemAtPath_error(patch, nil).NSFileSize;
    } catch (e) {
      size = 0;
    }

    return size;
  },
  renameFile: function renameFile(from, to) {
    this.fileManager.fileExistsAtPath(from) && this.fileManager.moveItemAtPath_toPath_error(from, to, null);
  },
  exist: function exist(path) {
    return !!this.fileManager.fileExistsAtPath(path);
  },
  readDir: function readDir(path) {
    return !!this.fileManager.fileExistsAtPath(path) && this.fileManager.contentsOfDirectoryAtPath_error_(path, nil);
  },
  removeDir: function removeDir(path) {
    this.fileManager.removeItemAtPath_error(path, null);
  },
  getTempDirPath: function getTempDirPath() {
    var URL = this.fileManager.URLsForDirectory_inDomains(13, 1).lastObject();
    var hash = Date.now() / 1e3;
    var nsString = NSString.stringWithFormat('%@', hash);
    return URL.URLByAppendingPathComponent(nsString).path();
  },
  mkTempDir: function mkTempDir(path) {
    var URL = this.getTempDirPath(path);
    return this.mkDir(URL) || URL;
  },

  /**
   * @param {String} image
   * @param {MSImageData} image
   */
  saveImage: function saveImage(path, image) {
    var tiffData = image.TIFFRepresentation();
    var p = NSBitmapImageRep.imageRepWithData(tiffData);
    var data = p.representationUsingType_properties(NSPNGFileType, null);
    data.writeToFile_atomically(path, !0);
  },
  jsonFilePaths: function jsonFilePaths(path) {
    var filename;
    var ds = this.fileManager.enumeratorAtPath(path);
    var paths = []; // eslint-disable-next-line no-cond-assign

    while (filename = ds.nextObject()) {
      if (filename.pathExtension() == 'json') {
        paths.push(filename);
      }
    }

    return paths;
  }
};

/***/ }),

/***/ "./src/utils/index.js":
/*!****************************!*\
  !*** ./src/utils/index.js ***!
  \****************************/
/*! exports provided: getImageURL, createImage, createImageView, createBoxSeparator, addButton, createBounds, createPanel, createView, createBox, createTextField, getSketchSelected, getSelected, getScriptExecPath, getDocumentID, getDocumentPath, getDocumentName, dumpLayer, dumpSymbol, penUrlInBrowser, getNewUUID, getThreadDictForKey, setThreadDictForKey, removeThreadDictForKey, getSettingForKey, setSettingForKey, removeSettingForKey, showPluginsPane, showLibrariesPane, getSystemVersion, getPluginVersion, reloadPlugins, getFileContentFromModal, getSavePathFromModal, observerWindowResizeNotification, removeObserverWindowResizeNotification, observerFullScreenStatusChangedNotification, removeObserverFullScreenStatusChangedNotification, File, getScreenInfo, getSplitViewController, getInspectorController, isSketchInspectorVisible, getContentContainerViewFromInspector, getSketchStackViewFromInspector, getSplitViewItemIndexForSketchInspector, insertItemToSplitViewAtIndex, getSplitItemIndex, removeItemFromSplitView, stackViewGravityTop, NSWindowAbove, isMacOSVersionAtLeast11 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getScreenInfo", function() { return getScreenInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSplitViewController", function() { return getSplitViewController; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getInspectorController", function() { return getInspectorController; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isSketchInspectorVisible", function() { return isSketchInspectorVisible; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getContentContainerViewFromInspector", function() { return getContentContainerViewFromInspector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSketchStackViewFromInspector", function() { return getSketchStackViewFromInspector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSplitViewItemIndexForSketchInspector", function() { return getSplitViewItemIndexForSketchInspector; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "insertItemToSplitViewAtIndex", function() { return insertItemToSplitViewAtIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSplitItemIndex", function() { return getSplitItemIndex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeItemFromSplitView", function() { return removeItemFromSplitView; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stackViewGravityTop", function() { return stackViewGravityTop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NSWindowAbove", function() { return NSWindowAbove; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isMacOSVersionAtLeast11", function() { return isMacOSVersionAtLeast11; });
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _element__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./element */ "./src/utils/element.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getImageURL", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["getImageURL"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createImage", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createImage"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createImageView", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createImageView"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createBoxSeparator", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createBoxSeparator"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "addButton", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["addButton"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createBounds", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createBounds"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createPanel", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createPanel"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createView", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createView"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createBox", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createBox"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "createTextField", function() { return _element__WEBPACK_IMPORTED_MODULE_1__["createTextField"]; });

/* harmony import */ var _selector__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./selector */ "./src/utils/selector.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getSketchSelected", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["getSketchSelected"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getSelected", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["getSelected"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getScriptExecPath", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["getScriptExecPath"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getDocumentID", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["getDocumentID"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getDocumentPath", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["getDocumentPath"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getDocumentName", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["getDocumentName"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "dumpLayer", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["dumpLayer"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "dumpSymbol", function() { return _selector__WEBPACK_IMPORTED_MODULE_2__["dumpSymbol"]; });

/* harmony import */ var _system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./system */ "./src/utils/system.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "penUrlInBrowser", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["penUrlInBrowser"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getNewUUID", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["getNewUUID"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getThreadDictForKey", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["getThreadDictForKey"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setThreadDictForKey", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["setThreadDictForKey"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "removeThreadDictForKey", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["removeThreadDictForKey"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getSettingForKey", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["getSettingForKey"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "setSettingForKey", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["setSettingForKey"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "removeSettingForKey", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["removeSettingForKey"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "showPluginsPane", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["showPluginsPane"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "showLibrariesPane", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["showLibrariesPane"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getSystemVersion", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["getSystemVersion"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getPluginVersion", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["getPluginVersion"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "reloadPlugins", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["reloadPlugins"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getFileContentFromModal", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["getFileContentFromModal"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "getSavePathFromModal", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["getSavePathFromModal"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "observerWindowResizeNotification", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["observerWindowResizeNotification"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "removeObserverWindowResizeNotification", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["removeObserverWindowResizeNotification"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "observerFullScreenStatusChangedNotification", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["observerFullScreenStatusChangedNotification"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "removeObserverFullScreenStatusChangedNotification", function() { return _system__WEBPACK_IMPORTED_MODULE_3__["removeObserverFullScreenStatusChangedNotification"]; });

/* harmony import */ var _file__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./file */ "./src/utils/file.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "File", function() { return _file__WEBPACK_IMPORTED_MODULE_4__["File"]; });






var getScreenInfo = function getScreenInfo() {
  return {
    width: Number(''.concat(NSScreen.mainScreen().frame().size.width)),
    height: Number(''.concat(NSScreen.mainScreen().frame().size.height))
  };
};
var getSplitViewController = function getSplitViewController(document) {
  return document.splitViewController();
};
var getInspectorController = function getInspectorController(document) {
  // 兼容 sketch 79 https://github.com/abynim/Sketch-Headers/commit/edd1b8aced0c2221dae035215291f049c368626d#diff-9733f7138985f7c622c4affb882becf48f2c0bb864a352ba07633d0de0071e09L40
  if (Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) >= 79) {
    return getSplitViewController(document).observableInspectorController();
  }

  return getSplitViewController(document).inspectorController();
};
var isSketchInspectorVisible = function isSketchInspectorVisible(document) {
  var splitViewController = getSplitViewController(document);
  var inspectorController = getInspectorController(document);
  return Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) >= 70 ? null !== splitViewController.splitViewItemForViewController(inspectorController) : splitViewController.splitView().arrangedSubviews().containsObject(inspectorController.view());
};
var getContentContainerViewFromInspector = function getContentContainerViewFromInspector(document) {
  return getInspectorController(document).contentContainerView();
};
var getSketchStackViewFromInspector = function getSketchStackViewFromInspector(document) {
  return getContentContainerViewFromInspector(document).superview();
};
var getSplitViewItemIndexForSketchInspector = function getSplitViewItemIndexForSketchInspector(document) {
  var splitViewController = getSplitViewController(document);
  var inspectorController = getInspectorController(document);

  if (Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) >= 70) {
    var splitViewItem = splitViewController.splitViewItemForViewController(inspectorController);
    return splitViewController.splitViewItems().indexOfObject(splitViewItem);
  }

  return splitViewController.splitView().arrangedSubviews().indexOfObject(inspectorController.view());
};
var insertItemToSplitViewAtIndex = function insertItemToSplitViewAtIndex(document, splitViewItem, index) {
  var splitViewController = getSplitViewController(document);
  Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) >= 70 ? splitViewController.insertSplitViewItem_atIndex(splitViewItem, index) : splitViewController.splitView().insertArrangedSubview_atIndex(splitViewItem.viewController().view(), index);
};
var getSplitItemIndex = function getSplitItemIndex(document, splitItem) {
  var splitViewController = getSplitViewController(document);
  return splitViewController.splitViewItems().indexOfObject(splitItem);
};
var removeItemFromSplitView = function removeItemFromSplitView(document, splitViewItem) {
  var splitViewController = getSplitViewController(document);
  Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) >= 70 ? splitViewController.removeSplitViewItem(splitViewItem) : splitViewController.splitView().removeArrangedSubview(splitViewItem.viewController().view());
};
var stackViewGravityTop = function stackViewGravityTop() {
  return Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) > 55 ? NSStackViewGravityTop : 1;
};
var NSWindowAbove = function NSWindowAbove() {
  return Number(sketch_dom__WEBPACK_IMPORTED_MODULE_0__["version"].sketch) >= 57 ? NSWindowAbove : 1;
};
var isMacOSVersionAtLeast11 = function isMacOSVersionAtLeast11() {
  try {
    return NSAppKitVersionNumber >= NSAppKitVersionNumber10_15;
  } catch (e) {
    return false;
  }
};

/***/ }),

/***/ "./src/utils/injectcolorToken.js":
/*!***************************************!*\
  !*** ./src/utils/injectcolorToken.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return injectColorToken; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);

var cacheMap = new Map();

function getTokens() {
  if (cacheMap.has('tokens')) return Promise.resolve(cacheMap.get('tokens'));
  return fetch('https://haitun.netease.com/api/haitun/spec/theme/get?name=color_white&specName=skin').then(function (res) {
    return res.json();
  }).then(function (res) {
    var _res$data;

    var tokens = res === null || res === void 0 ? void 0 : (_res$data = res.data) === null || _res$data === void 0 ? void 0 : _res$data.tokens;

    if (tokens) {
      cacheMap.set('tokens', tokens);
    }

    return tokens;
  });
}

function injectColorToken() {
  console.log('Start injectColorToken.');
  var doc = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.getSelectedDocument();
  getTokens().then(function (tokens) {
    try {
      tokens.forEach(function (_ref) {
        var name = _ref.name,
            value = _ref.value;

        if (name.startsWith('color') && value) {
          if (!doc.swatches.find(function (swatch) {
            return swatch.name === name;
          })) {
            var swatch = sketch__WEBPACK_IMPORTED_MODULE_0___default.a.Swatch.from({
              name: name,
              color: value
            });
            doc.swatches.push(swatch);
          }
        }
      }); // 去重下，删除旧文档中重复的 swatch，大量 swatch会造成性能问题

      var newSwatches = [];
      doc.swatches.forEach(function (item) {
        if (!newSwatches.find(function (swatch) {
          return swatch.name === item.name;
        })) {
          newSwatches.push(item);
        }
      });
      doc.swatches = newSwatches;
    } catch (error) {
      console.log(error);
    }

    console.log('Finish injectColorToken.');
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/utils/json2sketch.js":
/*!**********************************!*\
  !*** ./src/utils/json2sketch.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return jsonToSketch; });
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var from_sketch_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! from-sketch-json */ "./node_modules/from-sketch-json/lib/index.js");
/* harmony import */ var from_sketch_json__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(from_sketch_json__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash/get */ "./node_modules/lodash/get.js");
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_3__);
function _createForOfIteratorHelper(o, allowArrayLike) { var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"]; if (!it) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = it.call(o); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it.return != null) it.return(); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }






var adjustFrame = function adjustFrame(layer) {
  // eslint-disable-next-line default-case
  switch (layer.type) {
    case 'Image':
    case 'ShapePath':
    case 'Artboard':
      break;

    case 'Group':
    case 'Page':
    case 'Shape':
    case 'SymbolMaster':
      if (layer.layers && layer.layers.length !== 0) {
        layer.layers.forEach(adjustFrame);
      } else {
        layer.adjustToFit();
      }

  }
};

var errorMsg = '[Sketch JSON]不是有效的 Sketch JSON 对象😶';

function fixImageLayer(layer, nativeLayer) {
  // console.log('\n进入到 fixImageLayer 处理函数', layer, nativeLayer, '\n');
  if (!nativeLayer) return;

  if (layer._class === 'bitmap') {
    // 处理图层为图片
    var base64String = lodash_get__WEBPACK_IMPORTED_MODULE_3___default()(layer, 'image.data._data');

    if (base64String) {
      // @ts-ignore
      var image = NSData.alloc().initWithBase64EncodedString_options(base64String, // @ts-ignore
      NSDataBase64DecodingIgnoreUnknownCharacters);
      nativeLayer.image = image;
    }
  } // 处理图片背景


  var fills = lodash_get__WEBPACK_IMPORTED_MODULE_3___default()(layer, 'style.fills');

  if (fills) {
    fills.forEach(function (fill, index) {
      // console.log('\n处理前:\n', nativeLayer.style.fills[index]);
      if (fill.image) {
        var _base64String = lodash_get__WEBPACK_IMPORTED_MODULE_3___default()(fill, 'image.data._data');

        if (_base64String) {
          // @ts-ignore
          var _image = NSData.alloc().initWithBase64EncodedString_options(_base64String, // @ts-ignore
          NSDataBase64DecodingIgnoreUnknownCharacters); // @ts-ignore


          nativeLayer.style.fills[index].pattern.image = _image;
        }
      } // console.log('\n处理后:\n', nativeLayer.style.fills[index]);

    });
  } // 处理子层


  if (layer.layers) {
    layer.layers.forEach(function (subLayer, index) {
      fixImageLayer(subLayer, nativeLayer.layers[index]);
    });
  }
}
/**
 * 将单个 JSON 转换为 Sketch 对象
 * @param layer
 */


var transformToSketch = function transformToSketch(layer) {
  if (!layer._class) {
    sketch__WEBPACK_IMPORTED_MODULE_0__["UI"].message(errorMsg);
    return;
  }

  var nativeLayer = Object(from_sketch_json__WEBPACK_IMPORTED_MODULE_2__["fromSJSON"])(layer);
  var sketchObj = Object(sketch_dom__WEBPACK_IMPORTED_MODULE_1__["fromNative"])(nativeLayer);
  fixImageLayer(layer, sketchObj);
  sketchObj.selected = true;
  adjustFrame(sketchObj);
  return sketchObj;
};
/**
 * 复制 JSON 为 Sketch 图层
 * */


function jsonToSketch(json) {
  try {
    if (json instanceof Array) {
      var _iterator = _createForOfIteratorHelper(json),
          _step;

      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var obj = _step.value;
          return transformToSketch(obj);
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    } else {
      return transformToSketch(json);
    }
  } catch (e) {
    var message = e.message;

    if (message.includes('JSON Parse error: Unexpected identifier')) {
      sketch__WEBPACK_IMPORTED_MODULE_0__["UI"].message(errorMsg);
    } else {
      sketch__WEBPACK_IMPORTED_MODULE_0__["UI"].message(e);
    }
  }
}

/***/ }),

/***/ "./src/utils/renderCom.js":
/*!********************************!*\
  !*** ./src/utils/renderCom.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _json2sketch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./json2sketch */ "./src/utils/json2sketch.js");


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }


 // take a hex and give us a nice text color to put over it

/* harmony default export */ __webpack_exports__["default"] = (function (params, context) {
  var document = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.getSelectedDocument();
  var selectedLayers = document.selectedLayers;
  var layer = selectedLayers.layers[0];
  var asketch = params.sketchJson;
  var successLayers = Object(_json2sketch__WEBPACK_IMPORTED_MODULE_2__["default"])(asketch, params.time);
  successLayers.parent = layer.parent;
  successLayers.index = layer.index;
  successLayers.frame.x = layer.frame.x;
  successLayers.frame.y = layer.frame.y;
  successLayers.selected = true;
  layer.remove();
  var previousId = layer.id;

  if (successLayers.id) {
    var objectId = successLayers.id;
    sketch__WEBPACK_IMPORTED_MODULE_1___default.a.Settings.setSessionVariable('@render/lastObjetcId', objectId);
    sketch__WEBPACK_IMPORTED_MODULE_1___default.a.Settings.setDocumentSettingForKey(document, objectId, JSON.stringify(_objectSpread(_objectSpread({}, params), {}, {
      objectId: objectId
    }))); // 清楚垃圾数据

    sketch__WEBPACK_IMPORTED_MODULE_1___default.a.Settings.setDocumentSettingForKey(document, previousId, null);
  }
}); // export default (params, context) => {
//     let document = sketch.getSelectedDocument()
//     let selectedLayers = document.selectedLayers
//     let layer = selectedLayers.layers[0];
//     const asketch = params.sketchJson;
//     asketch.layers.forEach((ele, index) => {
//         const selected = selectedLayers.layers[0];
//         asketch.layers[index].frame.x = selected.frame.x
//         asketch.layers[index].frame.y = selected.frame.y
//     });
//     const successLayers = asketch2sketch(context, [asketch], {}, params.time)
//     layer.remove()
//     if (successLayers.length) {
//         const objectId = successLayers[0].id
//         sketch.Settings.setSessionVariable(objectId, JSON.stringify({
//             ...params,
//             objectId
//         }))
//     }
// }

/***/ }),

/***/ "./src/utils/selector.js":
/*!*******************************!*\
  !*** ./src/utils/selector.js ***!
  \*******************************/
/*! exports provided: getSketchSelected, getSelected, getScriptExecPath, getDocumentID, getDocumentPath, getDocumentName, dumpLayer, dumpSymbol */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSketchSelected", function() { return getSketchSelected; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSelected", function() { return getSelected; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getScriptExecPath", function() { return getScriptExecPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDocumentID", function() { return getDocumentID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDocumentPath", function() { return getDocumentPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDocumentName", function() { return getDocumentName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dumpLayer", function() { return dumpLayer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dumpSymbol", function() { return dumpSymbol; });
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../state */ "./src/state.js");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sketch */ "sketch");
/* harmony import */ var sketch__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(sketch__WEBPACK_IMPORTED_MODULE_1__);


/**
 * getSketchSelected 获取当前选择的 document， page， selection
 */

var getSketchSelected = function getSketchSelected() {
  var Document = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.Document;
  var document = Document.getSelectedDocument(); // 当前被选择的 document

  var page = document.selectedPage; // 当前被选择的 page

  var artboard = sketch__WEBPACK_IMPORTED_MODULE_1___default.a.Artboard.fromNative(page._object.currentArtboard());
  var selection = document.selectedLayers; // 当前选择图层

  return {
    document: document,
    page: page,
    artboard: artboard,
    selection: selection
  };
};
/**
 * getSelected 获取当前 document、page、artboard、selection
 */

var getSelected = function getSelected() {
  var document = _state__WEBPACK_IMPORTED_MODULE_0__["context"].document; // 获取 sketch 当前 document

  var plugin = _state__WEBPACK_IMPORTED_MODULE_0__["context"].plugin;
  var command = _state__WEBPACK_IMPORTED_MODULE_0__["context"].command;
  var page = document.currentPage(); // 当前被选择的 page

  var artboards = page.artboards(); // 所有的画板

  var selectedArtboard = page.currentArtboard(); // 当前被选择的画板

  var selection = _state__WEBPACK_IMPORTED_MODULE_0__["context"].selection; // 当前选择图层

  return {
    document: document,
    plugin: plugin,
    command: command,
    page: page,
    artboards: artboards,
    selectedArtboard: selectedArtboard,
    selection: selection
  };
};
/**
 * 获取当前脚本执行路径
 * @param {*} context
 */

var getScriptExecPath = function getScriptExecPath(context) {
  return context.scriptPath;
};
/**
 * document 获取所选择 document objectID
 */

var getDocumentID = function getDocumentID() {
  return _state__WEBPACK_IMPORTED_MODULE_0__["context"].document.documentData().objectID();
};
/**
 * getDocumentPath 获取所选择 document 路径
 */

var getDocumentPath = function getDocumentPath() {
  var Document = _state__WEBPACK_IMPORTED_MODULE_0__["context"].document;
  return Document.fileURL() ? Document.fileURL().path() : nil;
};
/**
 * getDocumentName 获取所选择 document name
 */

var getDocumentName = function getDocumentName() {
  return getDocumentPath(_state__WEBPACK_IMPORTED_MODULE_0__["context"]) ? getDocumentPath(_state__WEBPACK_IMPORTED_MODULE_0__["context"]).lastPathComponent() : nil;
};
/**
 * dumpLayer 导出json数据
 * @param {*} sketchObject  如 context.document.currentPage()
 */

var dumpLayer = function dumpLayer(sketchObject) {
  // return NSDictionary
  var jsonData = sketchObject.treeAsDictionary();
  var nsData = NSJSONSerialization.dataWithJSONObject_options_error_(jsonData, 0, nil);
  return NSString.alloc().initWithData_encoding_(nsData, 4);
};
/**
 * dumpSymbol 导出json数据
 * @param {*} symbolInstance // context.selection[0]
 */

var dumpSymbol = function dumpSymbol(symbolInstance) {
  // return symbolInstance
  var immutableInstance = symbolInstance.immutableModelObject();
  return MSJSONDataArchiver.archiveStringWithRootObject_error(immutableInstance, nil);
};

/***/ }),

/***/ "./src/utils/system.js":
/*!*****************************!*\
  !*** ./src/utils/system.js ***!
  \*****************************/
/*! exports provided: penUrlInBrowser, getNewUUID, getThreadDictForKey, setThreadDictForKey, removeThreadDictForKey, getSettingForKey, setSettingForKey, removeSettingForKey, showPluginsPane, showLibrariesPane, getSystemVersion, getPluginVersion, reloadPlugins, getFileContentFromModal, getSavePathFromModal, observerWindowResizeNotification, removeObserverWindowResizeNotification, observerFullScreenStatusChangedNotification, removeObserverFullScreenStatusChangedNotification */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "penUrlInBrowser", function() { return penUrlInBrowser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNewUUID", function() { return getNewUUID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getThreadDictForKey", function() { return getThreadDictForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setThreadDictForKey", function() { return setThreadDictForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeThreadDictForKey", function() { return removeThreadDictForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSettingForKey", function() { return getSettingForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setSettingForKey", function() { return setSettingForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeSettingForKey", function() { return removeSettingForKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showPluginsPane", function() { return showPluginsPane; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "showLibrariesPane", function() { return showLibrariesPane; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSystemVersion", function() { return getSystemVersion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPluginVersion", function() { return getPluginVersion; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reloadPlugins", function() { return reloadPlugins; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFileContentFromModal", function() { return getFileContentFromModal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSavePathFromModal", function() { return getSavePathFromModal; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "observerWindowResizeNotification", function() { return observerWindowResizeNotification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeObserverWindowResizeNotification", function() { return removeObserverWindowResizeNotification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "observerFullScreenStatusChangedNotification", function() { return observerFullScreenStatusChangedNotification; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeObserverFullScreenStatusChangedNotification", function() { return removeObserverFullScreenStatusChangedNotification; });
/* harmony import */ var mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mocha-js-delegate */ "./node_modules/mocha-js-delegate/index.js");
/* harmony import */ var mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _state__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../state */ "./src/state.js");


/**
 * openUrlInBrowser 浏览器打开链接
 * @param {string} url
 */

var penUrlInBrowser = function penUrlInBrowser(url) {
  NSWorkspace.sharedWorkspace().openURL(NSURL.URLWithString(url));
};
/**
 * getNewUUID 获取唯一 ID
 */

var getNewUUID = function getNewUUID() {
  return NSUUID.UUID().UUIDString();
};
/**
 * getThreadDictForKey 获取挂载 mainThread 的键值
 * @param {string} key
 */

var getThreadDictForKey = function getThreadDictForKey(key) {
  return NSThread.mainThread().threadDictionary()[key];
};
/**
 * setThreadDictForKey 挂载到 mainThread 的键值
 * @param {string} key
 * @param {string} value
 */

var setThreadDictForKey = function setThreadDictForKey(key, value) {
  return NSThread.mainThread().threadDictionary()[key] = value;
};
/**
 * removeThreadDictForKey 移除挂载到 mainThread 的键值
 * @param { string } key
 */

var removeThreadDictForKey = function removeThreadDictForKey(key) {
  if (NSThread.mainThread().threadDictionary()[key]) NSThread.mainThread().threadDictionary().removeObjectForKey(key);
};
/**
 * getSettingForKey 获取挂载 NSUserDefaults 的键值
 * @param { string } key
 */

var getSettingForKey = function getSettingForKey(key) {
  return NSUserDefaults.standardUserDefaults().objectForKey(key);
};
/**
 * setSettingForKey 挂载到 NSUserDefaults 的键值
 * @param {string} key
 * @param {string} value
 */

var setSettingForKey = function setSettingForKey(key, value) {
  return NSUserDefaults.standardUserDefaults().setObject_forKey(value, key);
};
/**
 * removeSettingForKey 移除挂载到 NSUserDefaults 的键值
 * @param { string } key
 */

var removeSettingForKey = function removeSettingForKey(key) {
  setSettingForKey(key, nil);
};
/**
 * showPluginsPane 显示 plugin window
 */

var showPluginsPane = function showPluginsPane() {
  var identifier = MSPluginsPreferencePane.identifier();
  var preferencesController = MSPreferencesController.sharedController();
  preferencesController.switchToPaneWithIdentifier(identifier);
  preferencesController.currentPreferencePane().tableView().reloadData();
};
/**
 * showLibrariesPane 显示 libraries window
 */

var showLibrariesPane = function showLibrariesPane() {
  var identifier = MSAssetLibrariesPreferencePane.identifier();
  var preferencesController = MSPreferencesController.sharedController();
  preferencesController.switchToPaneWithIdentifier(identifier);
  preferencesController.currentPreferencePane().tableView().reloadData();
};
/**
 * getSystemVersion 获取系统版本
 */

var getSystemVersion = function getSystemVersion() {
  try {
    var systemVersion = NSProcessInfo.processInfo().operatingSystemVersionString().match(/\d*\.\d*(\.\d*)?/);

    if (systemVersion && systemVersion[0]) {
      var versions = systemVersion[0];
      return versions.split('.').length === 2 ? ''.concat(versions, '.0') : versions;
    }

    return '0.0.0';
  } catch (e) {
    return '0.0.0';
  }
};
/**
 * getPluginVersion 获取插件版本
 */

var getPluginVersion = function getPluginVersion() {
  return _state__WEBPACK_IMPORTED_MODULE_1__["context"].plugin.version();
};
/**
 * reloadPlugins 重载插件
 */

var reloadPlugins = function reloadPlugins() {
  AppController.sharedInstance().pluginManager().reloadPlugins();
};
/**
 * getFileContentFromModal 打开文件选择器，获取文件的文本内容
 * @param {Array<string>} fileTypes 文件类型
 */

var getFileContentFromModal = function getFileContentFromModal() {
  var fileTypes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  var openPanel = NSOpenPanel.openPanel();
  openPanel.setTitle('Choose a JSON File');
  openPanel.canCreateDirectories = false;
  openPanel.canChooseFiles = true;
  openPanel.allowedFileTypes = fileTypes;
  var openPanelButtonPressed = openPanel.runModal();

  if (openPanelButtonPressed === NSModalResponseOK) {
    var filePath = openPanel.URL().path();
    return NSString.stringWithContentsOfFile_encoding_error(filePath, NSUTF8StringEncoding, nil);
  }

  return '';
};
/**
 * getSavePathFromModal 获取文件的存储路径
 * @param {String} fileName 文件名
 * @param {Array<string>} fileTypes 文件类型
 */

var getSavePathFromModal = function getSavePathFromModal(fileName) {
  var fileTypes = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : ['json'];
  if (!fileName) return;
  var savePanel = NSSavePanel.savePanel();
  savePanel.canCreateDirectories = true;
  savePanel.nameFieldStringValue = fileName;
  savePanel.allowedFileTypes = fileTypes;
  var savePanelActionStatus = savePanel.runModal();

  if (savePanelActionStatus === NSModalResponseOK) {
    var filePath = savePanel.URL().path();
    return {
      filePath: filePath,
      fileName: savePanel.nameFieldStringValue()
    };
  }

  return false;
};
/**
 * observerWindowResizeNotification 监听窗口resize
 * @param {*} fn
 */

var observerWindowResizeNotification = function observerWindowResizeNotification(fn) {
  // Keep script around, otherwise everything will be dumped once its run
  // COScript.currentCOScript().setShouldKeepAround(true)
  if (!getThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_MOVE_INSTANCE"])) {
    // Create a selector
    var Selector = NSSelectorFromString('onWindowMove:');
    var delegate = new mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0___default.a({
      'onWindowMove:': function onWindowMove(notification) {
        // const bounds = NSScreen.mainScreen().frame()
        fn(notification);
        log('notification'); // NSNotificationCenter.defaultCenter().removeObserver_name_object(delegateInstance, NSWindowDidResizeNotification, nil)
      }
    }); // Don't forget to create a class instance of the delegate

    var delegateInstance = delegate.getClassInstance();
    NSNotificationCenter.defaultCenter().addObserver_selector_name_object(delegateInstance, Selector, NSWindowDidResizeNotification, nil);
    setThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_MOVE_INSTANCE"], delegateInstance);
    setThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_MOVE_SELECTOR"], Selector);
  }
};
/**
 * removeObserverWindowResizeNotification 清除监听窗口resize
 * @param {*} fn
 */

var removeObserverWindowResizeNotification = function removeObserverWindowResizeNotification() {
  var delegateInstance = getThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_MOVE_INSTANCE"]);

  if (delegateInstance) {
    NSNotificationCenter.defaultCenter().removeObserver_name_object(delegateInstance, NSWindowDidResizeNotification, nil);
    removeThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_MOVE_INSTANCE"]);
    removeThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_MOVE_SELECTOR"]);
  }
};
/**
 * observerfullScreenStatusChangedNotification 监听窗口全屏
 * @param {*} fn
 */

var observerFullScreenStatusChangedNotification = function observerFullScreenStatusChangedNotification(fn) {
  if (!getThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_FULL_SCREEN_SELECTOR"])) {
    var Selector = NSSelectorFromString('fullScreenStatusChanged:');
    var delegate = new mocha_js_delegate__WEBPACK_IMPORTED_MODULE_0___default.a({
      'fullScreenStatusChanged:': function fullScreenStatusChanged(notification) {
        fn(notification);
        log('fullScreenStatusChanged!');
      }
    }); // Don't forget to create a class instance of the delegate

    var delegateInstance = delegate.getClassInstance();
    NSNotificationCenter.defaultCenter().addObserver_selector_name_object(delegateInstance, Selector, NSWindowDidEnterFullScreenNotification, nil);
    NSNotificationCenter.defaultCenter().addObserver_selector_name_object(delegateInstance, Selector, NSWindowDidExitFullScreenNotification, nil);
    setThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_FULL_SCREEN_INSTANCE"], delegateInstance);
    setThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_FULL_SCREEN_SELECTOR"], Selector);
  }
};
/**
 * removeObserverWindowResizeNotification 清除监听窗口resize
 * @param {*} fn
 */

var removeObserverFullScreenStatusChangedNotification = function removeObserverFullScreenStatusChangedNotification() {
  var delegateInstance = getThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_FULL_SCREEN_INSTANCE"]);

  if (delegateInstance) {
    NSNotificationCenter.defaultCenter().removeObserver_name_object(delegateInstance, NSWindowDidEnterFullScreenNotification, nil);
    NSNotificationCenter.defaultCenter().removeObserver_name_object(delegateInstance, NSWindowDidExitFullScreenNotification, nil);
    removeThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_FULL_SCREEN_INSTANCE"]);
    removeThreadDictForKey(_state__WEBPACK_IMPORTED_MODULE_1__["WINDOW_FULL_SCREEN_SELECTOR"]);
  }
};

/***/ }),

/***/ "./src/webview/sidePanel.js":
/*!**********************************!*\
  !*** ./src/webview/sidePanel.js ***!
  \**********************************/
/*! exports provided: BrowserManage, Browser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowserManage", function() { return BrowserManage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Browser", function() { return Browser; });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var url_parse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! url-parse */ "./node_modules/url-parse/index.js");
/* harmony import */ var url_parse__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(url_parse__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch-module-web-view */ "./node_modules/sketch-module-web-view/lib/index.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view__WEBPACK_IMPORTED_MODULE_2__);



var BrowserManage = {
  list: [],
  add: function add(browser) {
    this.list.push(browser);
  },
  get: function get(identifier) {
    return this.list.find(function (d) {
      return d.identifier === identifier;
    });
  },
  getCurrent: function getCurrent() {
    return this.list.find(function (d) {
      return d.browserWindow.isVisible();
    });
  },
  empty: function empty() {
    this.list = [];
  }
};
var Browser = function Browser(options) {
  _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Browser);

  this.options = Object.assign({
    width: 290,
    height: 550,
    minimizable: false,
    resizable: false,
    transparent: false,
    closable: false,
    center: false,
    alwaysOnTop: true,
    titleBarStyle: 'hiddenInset',
    hidesOnDeactivate: false,
    frame: false,
    show: false,
    hasShadow: false,
    acceptsFirstMouse: true
  }, options);
  this.identifier = options.identifier;
  this.document = options.document;
  var existBrowser = BrowserManage.get(options.identifier);

  if (existBrowser) {
    if (options.url && existBrowser.options.url !== options.url) {
      var originParsedUrl = url_parse__WEBPACK_IMPORTED_MODULE_1___default()(existBrowser.options.parse);
      var parsedUrl = url_parse__WEBPACK_IMPORTED_MODULE_1___default()(options.url);

      if (originParsedUrl.host !== parsedUrl.host) {
        existBrowser.browserWindow.loadURL(options.url);
      } else {
        existBrowser.browserWindow.webContents.executeJavaScript("umiHistory && umiHistory.push(".concat(parsedUrl.pathname, ")"));
      }

      existBrowser.options.url = options.url;
    }

    return existBrowser;
  }

  this.browserWindow = new sketch_module_web_view__WEBPACK_IMPORTED_MODULE_2___default.a(this.options);
  options.url && this.browserWindow.loadURL(options.url);
  BrowserManage.add(this);
};

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['fixSingleLineLineHeight'] = __skpm_run.bind(this, 'fixSingleLineLineHeight');
globalThis['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=index.js.map