//
//  SceneDelegate.h
//  TextHeightFixDemo
//
//  Created by Ang Li on 2022/5/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

